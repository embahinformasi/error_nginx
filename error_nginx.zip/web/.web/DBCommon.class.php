<?php 

class DBCommon {
	function __construct() {

	}

	function __destruct() {

	}

	public function SelectDataReceiptLocal($db, $filename, $receipt_no) {
		$state = 0;

		$sql = "select count(*) as jml from receipt 
						where receipt_no='$receipt_no' ";
		$db->query($sql);	
		$data_jml = $db->single();			
		$cnt_data = $data_jml["jml"];			
		$state = $cnt_data;

		return $state;
	}

	public function InsertDataReceiptLocal($db, $receipt_date, $receipt_no, $sub_total, $discount,
		$service, $tax, $total, $filename, $keterangan) {

		$state = 0;
		$sql = "insert into receipt (receipt_no, receipt_date, discount, tax, 
							service, sub_total, total, keterangan, state, draft) 
						values(:receipt_no, :receipt_date, :discount, :tax, :service,:sub_total, :total, 
							:keterangan, 0, 1) ";		
		//echo $sql."\n";

		$db->query($sql);
		$db->bind(':receipt_date', $receipt_date);	
		$db->bind(':receipt_no', $receipt_no);	
		$db->bind(':sub_total', $sub_total);	
		$db->bind(':discount', $discount);	
		$db->bind(':service', $service);	
		$db->bind(':tax', $tax);	
		$db->bind(':total', $total);	
		$db->bind(':keterangan', $keterangan);	
		$res = $db->execute();	

		if($res)
			$state = 1;

		return $state;
	}

	public function SelectDataReceipt($db, $table_name, $filename, $dev_id, $receipt_no) {
		$state = 0;

		$sql = "select count(*) as jml from `$table_name` 
						where filename='$filename' and receipt_no='$receipt_no' ";
		$db->query($sql);	
		$data_jml = $db->single();			
		$cnt_data = $data_jml["jml"];			
		//echo "jumlah data $cnt_data \n";
		$state = $cnt_data;

		return $state;
	}

	public function InsertDataReceipt($db, $table_name, $receipt_date, $receipt_no, $dev_id, $nontax, $sub_total, $discount,
		$service, $tax, $total, $filename, $keterangan) {

		$state = 0;
		$sql = "insert into `$table_name` (receipt_date, receipt_no, dev_id, nontax, sub_total, discount, servis, 
							tax, total, filename, void, receipt_head) 
						values(:receipt_date, :receipt_no, :dev_id, :nontax, :sub_total,:discount, :service, 
							:tax, :total, :filename, 1, :receipt_head) ";		
		//echo $sql."\n";

		$db->query($sql);
		$db->bind(':receipt_date', $receipt_date);	
		$db->bind(':receipt_no', $receipt_no);	
		$db->bind(':dev_id', $dev_id);	
		$db->bind(':nontax', $nontax);	
		$db->bind(':sub_total', $sub_total);	
		$db->bind(':discount', $discount);	
		$db->bind(':service', $service);	
		$db->bind(':tax', $tax);	
		$db->bind(':total', $total);	
		$db->bind(':filename', $filename);	
		$db->bind(':receipt_head', $keterangan);	
		$res = $db->execute();	

		if($res)
			$state = 1;

		return $state;
	}

	public function UpdateDataReceipt($db, $table_name, $receipt_date, $receipt_no, $dev_id, $nontax, $sub_total, $discount,
		$service, $tax, $total, $filename, $keterangan) {

		$state = 0;
		$sql = "update `$table_name` set tax=:tax, total=:total, servis=:service, discount=:discount, 
							sub_total=:sub_total 
						where filename=:filename and dev_id=:dev_id and receipt_no=:receipt_no ";	
		//echo $sql."\n";
		$db->query($sql);
		$db->bind(':dev_id', $dev_id);	
		$db->bind(':sub_total', $sub_total);	
		$db->bind(':discount', $discount);	
		$db->bind(':service', $service);	
		$db->bind(':tax', $tax);	
		$db->bind(':total', $total);	
		$db->bind(':filename', $filename);	
		$db->bind(':receipt_no', $receipt_no);	
		$res = $db->execute();	

		if($res)
			$state = 1;

		return $state;
	}

	public function GetCronState($db) {
		$state = array();
		$sql = "select ts_process, last_id from state";
		$db->query($sql);	
		$state = $db->single();
		return $state;
	}

	public function UpdateTimeCron($db){
		try {
			$next_time = strtotime("+30 seconds");
			$sql = "update state set ts_process='$next_time' ";
			$db->query($sql);
			$db->execute();
		}
		catch(Exception $e) {
			$db->CloseDb();
		}
	}

	public function ClearTimeCron($db){
		try {
			$next_time = strtotime("+10 seconds");
			$sql = "update state set ts_process='$next_time' ";
			$db->query($sql);
			$db->execute();
		}
		catch(Exception $e) {
		}
	}	

	public function UpdateLastIdServer($dev_id, $db, $last_id) {
		try {
			$sql = "update state set last_id='$last_id' ";
			$db->query($sql);
			$db->execute();
		}
		catch(Exception $e) {

		}
	}

	public function UpdateLastId($db, $dsn, $last_id) {
		try {			
			$next_time = strtotime("+30 seconds");
			$sql = "update state set last_id='$last_id' ";
			$db->query($sql);
			$db->execute();
		}
		catch(Exception $e) {
		}
	
	}	
}

?>
