<?php 

class PDOAccess extends PDO {
	
	protected $dbconn = null,
	$db_host = null,
	$db_user = null,
	$db_pass = null,
	$db_name = null,
	$db_port = null,
	$db_type = null,
	$stmt = null,
	$db_query = null,
	$error = "";
		
	function __construct($db_host, $db_user, $db_pass, $db_name, $db_port, $db_type=0) {
		$this->db_host 	= $db_host;
		$this->db_user 	= $db_user;
		$this->db_pass 	= $db_pass;
		$this->db_name 	= $db_name;
		$this->db_port 	= $db_port;
		$this->db_type	= $db_type;
	}
	
	public function getDbHost() {
		return $this->db_host;
	}
	
	public function getDbName() {
		return $this->db_name;
	}	
	
	public function getDbPort() {
		return $this->db_port;
	}

	public function GetDSN() {
		
		/*
		1=Mysql/Maria DB, 2=SQL Server, 3=Oracle,	4=PostgreSql, 5=Firebird,
		6=ODBC, 7=Sqlite, 8=db2, 9=ProgressDB/Opend Edge, 10=Sybase, 11=Apache Derby 	
		*/
		$dsn = "";
		$db_type = $this->db_type;

		if($db_type == "1")
			$dsn = "mysql:dbname=".$this->getDbName().";host=".$this->getDbHost().";port=".$this->getDbPort()."";
		elseif($db_type == "2")
			$dsn = "dblib:host=".$this->getDbHost().":".$this->getDbPort().";dbname=".$this->getDbName()."";
		elseif($db_type == "3")
			$dsn = "";
		elseif($db_type == "4")
			$dsn = "pgsql:dbname=".$this->getDbName().";host=".$this->getDbHost().";port=".$this->getDbPort().";";
		elseif($db_type == "5")
			$dsn = "firebird:dbname=".$this->getDbHost()."/".$this->getDbPort().":".$this->getDbName().";";
		elseif($db_type == "6")
			$dsn = "";
		elseif($db_type == "7")
			$dsn = "sqlite:".$this->getDbName()."";
		elseif($db_type == "8")
			$dsn = "";
		elseif($db_type == "9")
			$dsn = "";
		elseif($db_type == "10")
			$dsn = "";
		elseif($db_type == "11")
			$dsn = "";
		else
			$dsn = "mysql:dbname=".$this->getDbName().";host=".$this->getDbHost().";port=".$this->getDbPort()."";

		return $dsn;		
	}		
	
	public function OpenDb($dsn){

		$options = array(
			PDO::ATTR_PERSISTENT    => true,
			PDO::ATTR_ERRMODE       => PDO::ERRMODE_EXCEPTION
    );		
		
		if($this->dbconn !== null) { 
			return $this;
		} 
		else {
			try {
				if($this->db_user == null)
					$this->dbconn = new PDO($dsn, null, null, $options);
				else
					$this->dbconn = new PDO($dsn, $this->db_user, $this->db_pass, $options);
			}
			catch(Exception $e) {

				$this->error = $e->getMessage();
				echo "error occured : ".$this->error." \n";
			}
		}		
	}

	public function OpenDbSSL($dsn, $key, $cert, $ca) {

		$options = array(
			PDO::ATTR_PERSISTENT    => true,
			PDO::ATTR_ERRMODE       => PDO::ERRMODE_EXCEPTION,
			PDO::MYSQL_ATTR_SSL_KEY   =>$key,
			PDO::MYSQL_ATTR_SSL_CERT	=>$cert,
			PDO::MYSQL_ATTR_SSL_CA    =>$ca			
    );			

		if($this->dbconn !== null) { 
			return $this;
		} 
		else {
			try {
				$this->dbconn = new PDO($dsn, $this->db_user, $this->db_pass, $options);
			}
			catch(Exception $e) {
				$this->error = $e->getMessage();
				echo "error occured : ".$this->error." \n";
			}
		}			
	}
	
	function __destruct() {

	}
	
	public function CheckConnection() {
		if($this->dbconn) {
			return true;
		}
		else {
			return false;		
		}
	}
	
	public function CloseDb() {
		if($this->dbconn !== null)
			$this->dbconn = null;		
	}
	
	public function BeginTrans() {
		return $this->dbconn->beginTransaction();
	}	
	
	public function CommitTrans() {
		return $this->dbconn->commit();
	}
	
	public function RollbackTrans() {
		return $this->dbconn->rollBack();
	}
	
	public function query($query) {
		$this->stmt = $this->dbconn->prepare($query);
	}	
	
	public function bind($param, $value, $type = null) {
		if (is_null($type)) {
			switch (true) {
				case is_int($value):
					$type = PDO::PARAM_INT;
					break;
				case is_bool($value):
					$type = PDO::PARAM_BOOL;
					break;
				case is_null($value):
					$type = PDO::PARAM_NULL;
					break;
				default:
					$type = PDO::PARAM_STR;
			}
		}
		$this->stmt->bindValue($param, $value, $type);
	}

	public function execute() {
		return $this->stmt->execute();
	}	
	
	public function resultset($type) {
		$this->execute();
		if($type == "1")
			return $this->stmt->fetchAll(PDO::FETCH_ASSOC);
		else 
			return $this->stmt->fetchAll(PDO::FETCH_NUM);
	}	
	
	public function single() {
		$this->execute();
		return $this->stmt->fetch(PDO::FETCH_ASSOC);
	}	
	
	public function lastInsertId() {
		return $this->dbconn->lastInsertId();
	}	

	public function rowCount() {
		return $this->stmt->rowCount();
	}	
	
	public function debugDumpParams() {
		return $this->stmt->debugDumpParams();
	}	
	
	public function columnCount() {
		return $this->stmt->columnCount();
	}
	
	public function getMeta($num) {
		return $this->stmt->getColumnMeta($num);
	}

	public function setLastQuery($sql) {
		$this->db_query = $sql;
	}

	public function getLastQuery() {
		return $this->db_query();
	}
	
	public function dumpData($arr) {
		echo "<pre>";
			print_r($arr);
		echo "<pre>";
	}	
}
?>
