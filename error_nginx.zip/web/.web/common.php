<?php 
function SessionStart()
{
	$secure = true;
	$httponly = true;

	/*
	if (ini_set('session.use_only_cookies', 1) === FALSE) {
			header("Location: error.php?err=Could not initiate a safe session (ini_set)");
			exit();
	}		
	
	$cookieParams = session_get_cookie_params();
	
	session_set_cookie_params($cookieParams["lifetime"],
			$cookieParams["path"], 
			$cookieParams["domain"], 
			$secure,
			$httponly);		
	*/
	// Sets the session name to the one set above.
	//session_name($session_name);
	session_start();            // Start the PHP session 
	//session_regenerate_id(true);    // regenerated the session, delete the old one. 
}

function get_month_name_alias($month)
{
	$monthName = "";
	switch($month)
	{
		case "01":
			$monthName = "Jan";
			break;
		case "02":
			$monthName = "Feb";
			break;
		case "03":
			$monthName = "Mar";
			break;
		case "04":
			$monthName = "April";
			break;
		case "05":
			$monthName = "May";
			break;
		case "06":
			$monthName = "Jun";
			break;
		case "07":
			$monthName = "Jul";
			break;
		case "08":
			$monthName = "Aug";
			break;
		case "09":
			$monthName = "Sep";
			break;
		case "10":
			$monthName = "Oct";
			break;
		case "11":
			$monthName = "Nov";	
			break;
		case "12":
			$monthName = "Dec";				
			break;
	}
		
	return $monthName;
}	

function get_month_name($month)
{
	$monthName = "";
	switch($month)
	{
		case "01":
			$monthName = "Januari";
			break;
		case "02":
			$monthName = "Februari";
			break;
		case "03":
			$monthName = "Maret";
			break;
		case "04":
			$monthName = "April";
			break;
		case "05":
			$monthName = "Mei";
			break;
		case "06":
			$monthName = "Juni";
			break;
		case "07":
			$monthName = "Juli";
			break;
		case "08":
			$monthName = "Agustus";
			break;
		case "09":
			$monthName = "September";
			break;
		case "10":
			$monthName = "Oktober";
			break;
		case "11":
			$monthName = "November";	
			break;
		case "12":
			$monthName = "Desember";				
			break;
	}
		
	return $monthName;
}	

function days_in_month($month, $year) 
{ 
	// calculate number of days in a month 
	return $month == 2 ? ($year % 4 ? 28 : ($year % 100 ? 29 : ($year % 400 ? 28 : 29))) : (($month - 1) % 7 % 2 ? 30 : 31); 
} 	

function DownloadFile($file, $filename) { // $file = include path 

	if(file_exists($file)) {
			header('Content-Description: File Transfer');
			header('Content-Type: application/octet-stream');
			header('Content-Disposition: attachment; filename='.$filename);
			header('Content-Transfer-Encoding: binary');
			header('Expires: 0');
			header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
			header('Pragma: public');
			header('Content-Length: ' . filesize($file));
			ob_clean();
			flush();
			readfile($file);
			exit;
	}
}

function GetProviderName($db_provider) {
	$provider_name = "";

	if($db_provider == "1")
		$provider_name = "Mysql/Maria DB";
	elseif($db_provider == "2")
		$provider_name = "Sql Server";
	elseif($db_provider == "3")
		$provider_name = "Oracle";
	elseif($db_provider == "4")
		$provider_name = "Postgresql";
	elseif($db_provider == "5")
		$provider_name = "Firebird";
	elseif($db_provider == "6")
		$provider_name = "ODBC";
	elseif($db_provider == "7")
		$provider_name = "Sqlite";
	elseif($db_provider == "8")
		$provider_name = "DB2";
	elseif($db_provider == "9")
		$provider_name = "Progress DB/Open Edge";
	elseif($db_provider == "10")
		$provider_name = "Sybase";
	elseif($db_provider == "11")
		$provider_name = "Apache Derby";
	else
		$provider_name = "Mysql/Maria DB";	

	return $provider_name;
}				

function SetTimeZone($time_zone) {
	if($time_zone == 1)
		date_default_timezone_set("Asia/Jakarta");
	elseif($time_zone == 2)
		date_default_timezone_set("Asia/Makassar");
	else
		date_default_timezone_set("Asia/Jayapura");
}
?>
