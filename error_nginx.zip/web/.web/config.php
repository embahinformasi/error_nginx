<?php
//local db config
define("G_DB_HOST", "localhost");
define("G_DB_USER", "root");
define("G_DB_PASS", "@subaga2016");
define("G_DB_NAME", "tap_server");
define("G_DB_PORT", "3306");
?>
