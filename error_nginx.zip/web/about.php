<?php
	$page = $_SERVER['PHP_SELF'];
	$sec = "5000";
	$title = "About";
	$current_url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>

<?php include 'head-nav.php'; ?>
<div id="content-wrapper">
	<div class="mui--appbar-height"></div>
	<div class="mui-container-fluid" id="content">
		<div class="mui-row">
			<div class="mui-col-md-12">
				<h1>About TappingBox V3</h1>
			</div>
		</div>
		
		<div class="mui-row">
			<div class="mui-col-md-6">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend>Credits</legend>
					<table class="mui-table mui-table--bordered">
						<tr>
							<td><strong>Lead</strong></td>
							<td>Indra Kristiawan</td>							
						</tr>
						<tr>
							<td><strong>Main</strong></td>
							<td>Andriudin, Febi, Hilmy Rosadi, Igun, Rahmat, Sudiyatmo</td>							
						</tr>
						<tr>
							<td><strong>Support</strong></td>
							<td>Erick(Nesyer), Iwan, Son</td>							
						</tr>
						<tr>
							<th colspan="2" style="font-size:large; text-align:center;">TKI Base, Bandung - 2016</th>
						</tr>
					</table>
					Please Report any bugs to:	<a href="mailto:tappingboxv3">tappingboxv3@gmail.com</a>
				</div>
			</div>
			<div class="mui-col-md-6">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend>Documentation</legend>
						<A href=/web/doc/TBV3%20FIRMWARE%20SYSTEM%20DESCRIPTION.pdf>Short Description</A><br>
						<A href=/web/doc//Manual%20Instalasi%20TappingBox%20V3.pdf>Manual Installation</A>
				</div>
			</div>
		</div>
		<div class="mui-row">
			<div class="mui-col-md-12">
				<div class="mui-panel mui--bg-color-grey-50">
					<?php
						$notes=file_get_contents('/opt/web/tbv3notes.txt');
						echo nl2br($notes);
					?>
				</div>
			</div>
		</div>
		<div class="mui-row">
			<div class="mui-col-md-12">
				<div class="mui-panel mui--bg-color-grey-50">
					<?php
						$notes=file_get_contents('/opt/web/tbv3notes.txt');
						//echo nl2br($notes);
					?>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include 'footer.php'; ?>

