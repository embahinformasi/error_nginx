<?php
	$title = "Administrator";
	$tmpdir="/tmp/tbv3/www";
	exec ("[[ -d $tmpdir ]]||{ sudo mkdir -p $tmpdir;sudo chmod 0777 $tmpdir; } ");
	if(isset($_POST['ping'])){
		$destip=$_POST["destip"];
		$interface=$_POST["interface"];
		if(empty($interface)){
			exec("ping -c 3 $destip|grep loss>$tmpdir/resping");
			$resping=file_get_contents("$tmpdir/resping");
		}else{
			exec("ping -c 3 -I $interface $destip|grep loss >$tmpdir/resping");
			$resping=file_get_contents("$tmpdir/resping");
		}
	}
	
	if(isset($_FILES['uplod'])){
		$errors= array();
		$file_name = $_FILES['uplod']['name'];
		$file_size =$_FILES['uplod']['size'];
		$file_tmp =$_FILES['uplod']['tmp_name'];
    $file_type=$_FILES['uplod']['type'];

    $file_ext=strtolower(end(explode('.',$_FILES['uplod']['name'])));
    $expensions= array("tar.bz2","bz2");
    if(in_array($file_ext,$expensions)=== false) $errors[]="Please upload compressed tar.bz2 upgrade files";

		if(empty($errors)==true){
			exec('[[ -d /tmp/upgrade ]] || { sudo mkdir -p /tmp/upgrade/;sudo chmod 0777 /tmp/upgrade; }');
      $target_dir = "/tmp/upgrade/";
      $target_file = $target_dir . basename($_FILES['uplod']['name']);
      move_uploaded_file($_FILES['uplod']['tmp_name'], $target_file);
		} 
			
	} else if (isset($_POST['cleandata'])){
		exec('sudo /opt/script/cleandata');
		exec('echo 0|sudo tee /var/runtbv3/statistic/new');
		exec('echo 0|sudo tee /var/runtbv3/statistic/processed');
		exec('echo 0|sudo tee /var/runtbv3/statistic/send');
	} else if (isset($_POST['cleanlog'])){
		exec('sudo /opt/install/cleanlog');
	} else if (isset($_POST['reboot'])){
		exec('echo 1|sudo tee /tmp/tbv3/alarm/reboot');
		//exec('sudo /opt/tbexec/stopall');
		//exec('sudo reboot');
	} else if (isset($_POST['poweroff'])){
		exec('echo 0|sudo tee /tmp/tbv3/alarm/sysup');
		//exec('sudo /opt/tbexec/stopall');
		//exec('sudo poweroff');
	} else if (isset($_POST['bdeluser'])){
		$err="";
		$count=$_POST["count"];
		if ($count > 3 ){
			$deluser=$_POST["deluser"];
			exec("sudo sed -i \"/{$deluser}/d\" /etc/nginx/.htpasswd");
		}else $err="Cannot delete single user!";
	} else if(isset($_POST['badduser'])){
		$err="";
    $adduser=$_POST["adduser"];
    if(empty($adduser)){
			$err="Please input user name!";
    }else{
			$exist=0;
      $i=1;
			for(;;){
				$handle = popen("sed \"{$i}q;d\" /etc/nginx/.htpasswd|sed 's/:.*//'|tr -d '\t\r\n'", 'r');
   			$read = fread($handle,128);
        pclose($handle);
				if(empty($read))break;
        if($read == $adduser){
          $err="Username already exist!";
				 	$exist=1;
					break;
				}
        $i++;
			}
			if($exist == 0){
				$pass=$_POST["pass"];
				$cpass=$_POST["cpass"];
				if (empty($pass) || empty($cpass)) $err="Please input password!";
				else if($pass!=$cpass) $err="Password not match!";
				else{
					exec("sudo htpasswd -b /etc/nginx/.htpasswd $adduser $pass");					
				}
			}
    }
  }
?>
<?php 
	// include header html dan menu navigasi
	include 'head-nav.php';
?>
<div id="content-wrapper">
	<div class="mui--appbar-height"></div>
	<div class="mui-container-fluid">
		<div class="row">
			<div class="mui-col-12">
				<h1>Administrator</h1>
			</div>
		</div>
		<div class="mui-row">
			<div class="mui-col-md-6">
				<h2>User Account</h2>

	<h3>Add user:</h3>
	<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
		<div class="mui-textfield mui-textfield--float-label">
			<input type="text" name="adduser" value="<?php echo $adduser; ?>">
			<label>UserName</label>
		</div>
		<div class="mui-textfield mui-textfield--float-label">
			<input type="text" name="pass" value="<?php echo $pass; ?>">
			<label>Password</label>
		</div>
		<div class="mui-textfield mui-textfield--float-label">
			<input type="text" name="cpass" value="<?php echo $cpass; ?>">
			<label>Confirm Password</label>
		</div>
		<input type="submit" name="badduser" value="Add" class="mui-btn mui-btn--small mui-btn--raised mui-btn--primary" name="update">
	</form>
  <?php
    if(isset($_POST['badduser'])){
			if(empty($err)==false)echo "$err<br/>";
			else echo "User $adduser successfully added!";
		}
	?>

	<h3>Remove user:</h3>
	<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
	<div class="mui-select mui-col-md-8">
	<select name="deluser">
		<!--- <option value="open">open</option>--->
		<?php
			$i=1;
			for(;;){
				$handle = popen("sed \"{$i}q;d\" /etc/nginx/.htpasswd|sed 's/:.*//'|tr -d '\t\r\n'", 'r');
    		$read = fread($handle,128);
    		pclose($handle);
				if(empty($read))break;
				if($read != "igunos"){
					echo "<option value=\"$read\">$read</option>";
				}
				$i++;
			}
		?>
	</select>
	</div>
	<input type="hidden" name="count" value=<?php echo "$i";?> >
	<input name="bdeluser" type="submit" value="Delete" onclick="return confirm('Are you sure?')" class="mui-btn mui-btn--small mui-btn--raised mui-btn--primary mui-col-md-2">
	</form>

	<?php
		if (isset($_POST['bdeluser'])){
			if(empty($err)==false) echo "$err<br/>";
			else echo "User $deluser succesfully removed<br/>";
		}
	?>
			</div>
			<div class="mui-col-md-6">
				<h2>Test Ping</h2>
				<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
				<div class="mui-textfield mui-textfield--float-label">
					<input type="text" name="destip" value="<?php echo $desip; ?>">
					<label>Destinantion</label>
				</div>
				Interface: 
					<select name="interface">
					<?php
						if(empty($interface)==false)echo "<option value=\"$interface\">$interface</option>";
						echo "<option value=\"\">Auto</option>";
						exec ("ls /sys/class/net | tee $tmpdir/IF");
						$i=1;
						for(;;){
							$handle = popen("sed \"{$i}q;d\" $tmpdir/IF|tr -d '\t\r\n'", 'r');
							$read = fread($handle,16);
							pclose($handle);
							if(empty($read))break;
							if($read!="lo" && $read!="tunl0" && $read!="wwan0"){
								echo "<option value=\"$read\">$read</option>";
							}
							$i++;
						}
					?>
					</select>
					<input type="submit" name="ping" value="Ping" class="mui-btn mui-btn--small mui-btn--raised mui-btn--primary">
				</form>
				<?php
					if(isset($_POST['ping'])){
						if(empty($resping)==false){
							echo "Ping Result: $resping<br>";
						}
					}
				?>			
			<h2>Upgrade Firmware</h2>Please provide a valid tbv3install-xxx.tar.bz2 installation files
			<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST" enctype="multipart/form-data"><p>
				<div class="mui-textfield mui-textfield--float-label">
					<input type="file" name="uplod">
					<label>File</label>
				</div>
				<input type="submit" value="Upload" class="mui-btn mui-btn--small mui-btn--raised mui-btn--primary">
			</form>
			<?php
				if(isset($_FILES['uplod'])){
					if(empty($errors)==true){
						echo "upgrading system..<br/>";
						exec("sudo /opt/script/upgrade $target_file >/tmp/upgrade.log 2>&1");

						$MSG=file_get_contents('/tmp/upgrade.log');
						echo nl2br($MSG);
					} else {
						echo "Error<br/>";
						print_r($errors);
					}
				}
			?>
			</div>
		</div>
		<div class="mui-row">
			<div class="mui-col-md-3">
				<h2>Log Files</h2>
				<form method="post"><p>
					<input Name="cleanlog" type="submit" value="ClearLog" onclick="return confirm('Are you sure?')" class="mui-btn mui-btn--small mui-btn--raised mui--bg-color-yellow-300">
					Clear all log files
				</p></form>
			</div>
			<div class="mui-col-md-3">
				<h2>Printer Data</h2><p>
				<form method="post">
					<input Name="cleandata" type="submit" value="ClearData" onclick="return confirm('Are you sure?')" class="mui-btn mui-btn--small mui-btn--raised mui--bg-color-yellow-300">
					Cear all captured data
				</p></form>
			</div>
			<div class="mui-col-md-3">
				<h2>Reboot</h2>
				<form method="post"><p>
					<input Name="reboot" type="submit" value="Reboot" onclick="return confirm('Are you sure?')" class="mui-btn mui-btn--small mui-btn--raised mui-btn--danger">
					Reboot the system
				</p></form>
			</div>
			<div class="mui-col-md-3">
				<h2>PowerOff</h2>
				<form method="post"><p>
					<input Name="poweroff" type="submit" value="PowerOff" onclick="return confirm('Are you sure?')" class="mui-btn mui-btn--small mui-btn--raised mui-btn--danger">
					Power Off the system
				</p></form>
			</div>
		</div>
	</div>
</div>
<?php include 'footer.php'; ?>
