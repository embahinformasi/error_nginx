<!DOCTYPE html>
<?php
$page = $_SERVER['PHP_SELF'];
$sec = "5";
if (isset($_POST['btrestart'])){exec('sudo /opt/tbexec/restart /opt/tbexec/tbalarmd');}
?>
<html>
	<head>
	<meta http-equiv="refresh" content="<?php echo $sec?>;URL='<?php echo $page?>'">
	</head>
	<title>TappingBoxV3</title>
	<body>
 	<body bgcolor="#00FFFF">
	<font face="monospace" color="#000000">
  <A href=home.php>Home</A>
  <A href=setup.php>Setup</A>
  <A href=status.php>Status</A>
  <A href=system.php>System</A>
	<br/>
	<A href=sysmon.php>Sysmon</A>
  <A href=alarm.php>Alarm</A>
  <A href=notif.php>Notifier</A>
  <A href=capstat.php>Printer</A>
  <A href=modem.php>Modem</A>
  <A href=update.php>Update</A>
  <A href=network.php>Network</A>

	<h1>Alarm Status</h1>

	<form method="post"><p><button name="btrestart">Restart</button>
    <?php
    if (file_exists('/tmp/tbv3/.tbalarmd')==TRUE) echo "Service alarm is up";
      else echo "Warning: Service alarm is stopped!";
    //echo nl2br("\n");
	?>
	</p></form>

  <h2>System Failure Alarm</h2>
	CPU Load=<?php>$A=(file_get_contents('/tmp/tbv3/alarm/cpuload'));echo "$A,"; ?>
  CPU Temperature=<?php>$A=(file_get_contents('/tmp/tbv3/alarm/cputemp'));echo "$A,"; ?>
  Memory=<?php>$A=(file_get_contents('/tmp/tbv3/alarm/memusage'));echo "$A,"; ?>
  Disk usage=<?php>$A=(file_get_contents('/tmp/tbv3/alarm/diskusage'));echo "$A,"; ?>

  <h2>Power Failure Alarm</h2>
	Power Supply=<?php> $A=(file_get_contents('/tmp/tbv3/alarm/pwrplug'));echo "$A,"; ?> 
	Battery Capacity=<?php> $A=(file_get_contents('/tmp/tbv3/alarm/battlvl'));echo "$A,"; ?> 

	<h2>Hardware Undetected Alarm</h2>
  Interface Serial=<?php>$A=(file_get_contents('/tmp/tbv3/alarm/intcap1'));echo "$A,"; ?>	
  Interface Lpt=<?php>$A=(file_get_contents('/tmp/tbv3/alarm/intcap2'));echo "$A,"; ?>	
  Interface USB=<?php>$A=(file_get_contents('/tmp/tbv3/alarm/intcap3'));echo "$A,"; ?> 	
  Lpt Converter=<?php>$A=(file_get_contents('/tmp/tbv3/alarm/lptatmega'));echo "$A,"; ?><br/>
  Interface Lan=<?php>$A=(file_get_contents('/tmp/tbv3/alarm/iflan'));echo "$A,"; ?> 	
  Interface Wifi=<?php>$A=(file_get_contents('/tmp/tbv3/alarm/ifwlan'));echo "$A,"; ?> 	
  Interface Modem=<?php>$A=(file_get_contents('/tmp/tbv3/alarm/ifmodem'));echo "$A,"; ?> 	


	<h2>Network Unconnected Alarm</h2>
	Modem=<?php> $A=(file_get_contents('/tmp/tbv3/alarm/conmodem'));echo "$A,"; ?>
	Lan=<?php> $A=(file_get_contents('/tmp/tbv3/alarm/conlan'));echo "$A,"; ?>
	Wifi=<?php> $A=(file_get_contents('/tmp/tbv3/alarm/conwlan'));echo "$A,"; ?>
	VPN=<?php> $A=(file_get_contents('/tmp/tbv3/alarm/convpn'));echo "$A,"; ?>

	<h2>GSM Failure Alarm</h2>
  Signal Strength=<?php> $A=(file_get_contents('/tmp/tbv3/alarm/sigmodem'));echo "$A,"; ?><br/>	
  Billing Info=<?php> $A=(file_get_contents('/tmp/tbv3/alarm/billmodem'));echo "$A,"; ?>	
  Quota Info=<?php> $A=(file_get_contents('/tmp/tbv3/alarm/quotamodem'));echo "$A,"; ?>	

  <h2>Tamper Detected Alarm</h2>
  Serial=<?php> $A=(file_get_contents('/tmp/tbv3/alarm/tser'));echo "$A,";?>
  LPT=<?php> $A=(file_get_contents('/tmp/tbv3/alarm/tlpt'));echo "$A,"; ?>
  USB=<?php> $A=(file_get_contents('/tmp/tbv3/alarm/tusb'));echo "$A,"; ?>
  Vibra=<?php> $A=(file_get_contents('/tmp/tbv3/alarm/tvibra'));echo "$A,"; ?>
  Casing=<?php> $A=(file_get_contents('/tmp/tbv3/alarm/tcasing'));echo "$A"; ?>

	</font>
	</body>
</html>
