<?php
	$page = $_SERVER['PHP_SELF'];
	$sec = "6000";
	$title = "Printer Capture Status";
	
	if (isset($_POST['btrestart'])){exec('sudo /opt/tbexec/tbcaptured restart');}
?>
<?php include 'head-nav.php'; ?>
<div id="content-wrapper">
	<div class="mui--appbar-height"></div>
	<div class="mui-container-fluid" id="content">
	<div id="Reload">
		<div class="mui-row">
			<div class="mui-col-md-12">
				<h1>Printer Capture Status</h1>
				<div class="mui--text-center">
				<?php
				if (file_exists('/tmp/tbv3/.tbcaptured')==TRUE)
					echo "<button class='mui-btn mui-btn--raised mui--bg-color-green-A400 sys-lbl'>Service Capture is running</button>";
				else
					echo "<button class='mui-btn mui-btn--raised mui-btn--danger sys-lbl'>Service TBCapture is stopped</button>";
				//echo nl2br("\n");
				if (file_exists('/tmp/tbv3/.tbdataprod')==TRUE)
					echo "<button class='mui-btn mui-btn--raised mui--bg-color-green-A400 sys-lbl'>Service Data Process is running</button>";
				else
					echo "<button class='mui-btn mui-btn--raised mui-btn--danger sys-lbl'>Service Data Process is stopped</button>";
				//echo nl2br("\n");
				if (file_exists('/tmp/tbv3/.tbdatasenderd')==TRUE)
					echo "<button class='mui-btn mui-btn--raised mui--bg-color-green-A400 sys-lbl'>Service Data Sender is running</button>";
				else
					echo "<button class='mui-btn mui-btn--raised mui-btn--danger sys-lbl'>Service Data Sender is stopped</button>";
				//echo nl2br("\n");
				if (file_exists('/tmp/tbv3/.tbquotactrld')==TRUE)
					echo "<button class='mui-btn mui-btn--raised mui--bg-color-green-A400 sys-lbl'>Service Quota Limiter is running</button>";
				else
					echo "<button class='mui-btn mui-btn--raised mui-btn--danger sys-lbl'>Service Quota Limiter is stopped</button>";
				?>
				</div>
				<form method="post">
					<button name="btrestart" class="mui-btn mui-btn--raised mui-btn--primary mui--pull-right">Restart</button>
				</form>
			</div>
		</div>
		<div class="mui-row">
			<div class="mui-col-md-4">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend class="mui--divider-bottom">Serial Interface</legend>
					<?php
						$handle = popen('tail /var/log/tbv3/tbcapture.serial.log 2>&1', 'r');
						$read = fread($handle, 2048);
						echo nl2br($read);
						pclose($handle);
					?>
				</div>
			</div>
			<div class="mui-col-md-4">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend class="mui--divider-bottom">LPT Interface</legend>
					<?php
						$handle = popen('tail /var/log/tbv3/tbcapture.lpt.log 2>&1', 'r');
						$read = fread($handle, 2048);
						echo nl2br($read);
						pclose($handle);
					?>
				</div>
			</div>
			<div class="mui-col-md-4">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend class="mui--divider-bottom">USB Interface</legend>
					<?php
						$handle = popen('tail /var/log/tbv3/tbcapture.usb.log 2>&1', 'r');
						$read = fread($handle, 2048);
						echo nl2br($read);
						pclose($handle);
					?>
				</div>
			</div>
		</div>
		<div class="mui-row">
			<div class="mui-col-md-6">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend class="mui--divider-bottom">Processing Data</legend>
					<?php
						$handle = popen('tail /var/log/tbv3/tbdataprod.log 2>&1', 'r');
						$read = fread($handle, 2048);
						echo nl2br($read);
						pclose($handle);
					?>
				</div>
			</div>
			<div class="mui-col-md-6">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend class="mui--divider-bottom">Sending Data</legend>
					<?php
						$handle = popen('tail /var/log/tbv3/tbdatasenderd.log 2>&1', 'r');
						$read = fread($handle, 2048);
						echo nl2br($read);
						pclose($handle);
					?>
				</div>
			</div>
			<div class="mui-col-md-12">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend class="mui--divider-bottom">Quota Data</legend>
					<?php
						$handle = popen('tail /var/log/tbv3/tbquotactrld.log 2>&1', 'r');
						$read = fread($handle, 2048);
						echo nl2br($read);
						pclose($handle);
					?>
				</div>
			</div>
		</div>
		<div class="mui-row">
			<div class="mui-col-md-12">
				<div class="mui-panel mui--bg-color-grey-50">
					Note: If you don't see anything, but all the services is up and running, don't panic!<br/>
					the log's just been logratated, you will see the activity again if any event occurs.
				</div>
			</div>
		</div>
	</div>
	</div>
</div>
<script>
/**
 * Refresh content Home dan status
 **/
var current_url = document.location;
function updateContent() {
		$("#content").load("<?echo "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";?> #Reload"); 
}
setInterval(updateContent, 15000); // 15 detik | 1000 = 1 dtk
</script>
<?php include 'footer.php'; ?>
