<?php
	$title = "Config";
	
	/*
	 *  Download konfigurasi File
	 */
	if($_POST['SaveFile']){
		$file = "/etc/tbv3/tbv3.conf";
		if (file_exists($file)) {
			header('Content-Type: application/octet-stream');
			header('Content-Disposition: attachment; filename="'.basename($file).'"');
			header('Expires: 0');
			header('Cache-Control: must-revalidate');
			header('Pragma: public');
			header('Content-Length: ' . filesize($file));
			readfile($file);
			exit;
		}
	}
  
  /*
   * Update, Reload, Default, Upload config
   */
  // Upload file config
  if(isset($_FILES['uplod'])){
			$errors= array();
			$file_name = $_FILES['uplod']['name'];
			$file_size =$_FILES['uplod']['size'];
			$file_tmp =$_FILES['uplod']['tmp_name'];
			if($file_size > 2097152) $errors[]='File Above 2MB, Too Big!';
			if(empty($errors)==true){
    		$target_file = "/etc/tbv3/tbv3.conf";
    		move_uploaded_file($_FILES['uplod']['tmp_name'], $target_file);
				define("FILE_NAME","$target_file");
			} 
    	else define("FILE_NAME", "/etc/tbv3/tbv3.conf");
		}
		// Restore Default config
		else if ($_POST["default"]) define("FILE_NAME", "/opt/script/tbv3.conf");
    else define("FILE_NAME", "/etc/tbv3/tbv3.conf");
		//echo "Working Files:";echo FILE_NAME;

		function Read() {
			echo @file_get_contents(FILE_NAME);
		}
		// Update configuration
    function Write(){
			$data = $_POST["textfile"];
			@file_put_contents(FILE_NAME, $data);
    }

    if ($_POST["update"]) Write();
    
	/*
	 * Tangkap kiriman form base-config dan update configurasi ke file /etc/tbv3/tbv3.conf
	 */
	if(!empty($_POST['basic-conf'])){
		
		$path_to_file = '/etc/tbv3/tbv3.conf'; //Lokasi file konfigurasi
		
		if($_POST['jns_tapping'] == 'printer'){
		 exec('putvalue /etc/tbv3/tbv3.conf tapping printer 1');
		 exec('putvalue /etc/tbv3/tbv3.conf tapping server 0');
		}else{
			exec('putvalue /etc/tbv3/tbv3.conf tapping printer 0');
			exec('putvalue /etc/tbv3/tbv3.conf tapping server 1');
		}
		exec('putvalue /etc/tbv3/tbv3.conf device id '.$_POST['dev_id']);
		exec('putvalue /etc/tbv3/tbv3.conf device address '.$_POST['dev_address']);
		
		$Update_timezone = file_get_contents($path_to_file); //Handling untuk replace konfig
		$Update_timezone = str_replace('timezone="'.exec('getvalue /etc/tbv3/tbv3.conf device timezone').'"','timezone="'.$_POST['dev_timezone'].'"',$Update_timezone);
		file_put_contents($path_to_file,$Update_timezone);
		
		exec('putvalue /etc/tbv3/tbv3.conf device latitude '.$_POST['dev_lat']);
		exec('putvalue /etc/tbv3/tbv3.conf device longitude '.$_POST['dev_lon']);
	 
		exec('putvalue /etc/tbv3/tbv3.conf gsm_info gsmnumber '.$_POST['gsm_number']);
		exec('putvalue /etc/tbv3/tbv3.conf gsm_info operator '.$_POST['gsm_apn']);
		
		$Update_url_ftp = file_get_contents($path_to_file); //Handling untuk replace konfig
		$Update_url_ftp = str_replace('url="'.exec('getvalue /etc/tbv3/tbv3.conf server1 url').'"','url="'.$_POST['server_url'].'"',$Update_url_ftp);
		file_put_contents($path_to_file,$Update_url_ftp);
		
		//exec('putvalue /etc/tbv3/tbv3.conf server1 url ftp://'.$_POST['server_url'].'/tap/');
		exec('putvalue /etc/tbv3/tbv3.conf server1 port '.$_POST['server_port']);
		exec('putvalue /etc/tbv3/tbv3.conf server1 user '.$_POST['server_user']);
		exec('putvalue /etc/tbv3/tbv3.conf server1 pass '.$_POST['server_pass']);
		
		$Update_url_profile = file_get_contents($path_to_file); //Handling untuk replace konfig
		$Update_url_profile = str_replace('url='.exec('getvalue /etc/tbv3/tbv3.conf notif_tb2_1 url'),'url=http://'.$_POST['server_notif'].'/server_sysmon/notifikasi_profile.php',$Update_url_profile);
		file_put_contents($path_to_file,$Update_url_profile);
		$Update_url_gpio = file_get_contents($path_to_file); //Handling untuk replace konfig
		$Update_url_gpio = str_replace('url='.exec('getvalue /etc/tbv3/tbv3.conf notif_tb2_2 url'),'url=http://'.$_POST['server_notif'].'/server_sysmon/notifikasi_gpio.php',$Update_url_gpio);
		file_put_contents($path_to_file,$Update_url_gpio);
		
		//exec('putvalue /etc/tbv3/tbv3.conf notif_tb2_1 url http://'.$_POST['server_notif'].'/server_sysmon/notifikasi_profile.php');
		//exec('putvalue /etc/tbv3/tbv3.conf notif_tb2_2 url http://'.$_POST['server_notif'].'/server_sysmon/notifikasi_gpio.php');
		}
    
	/*
	 * Ambil value saat ini
	 */
	$dev_id = exec('getvalue /etc/tbv3/tbv3.conf device id');
	$address = exec('getvalue /etc/tbv3/tbv3.conf device address');
	$timezone = exec('getvalue /etc/tbv3/tbv3.conf device timezone');
	if(exec('getvalue /etc/tbv3/tbv3.conf tapping printer') == 1){
		$jns_tapping = "printer";
	}else{
		$jns_tapping = "server";
	}
	$latitude = exec('getvalue /etc/tbv3/tbv3.conf device latitude');
	$longitude = exec('getvalue /etc/tbv3/tbv3.conf device longitude');
	$server_url = exec('getvalue /etc/tbv3/tbv3.conf server1 url');
	$server_port = exec('getvalue /etc/tbv3/tbv3.conf server1 port');
	$server_user = exec('getvalue /etc/tbv3/tbv3.conf server1 user');
	$server_pass = exec('getvalue /etc/tbv3/tbv3.conf server1 pass');
	$server_notif = explode("/", exec('getvalue /etc/tbv3/tbv3.conf notif_tb2_1 url'));
	$gsm_number = exec('getvalue /etc/tbv3/tbv3.conf gsm_info gsmnumber');
	$gsm_apn = exec('getvalue /etc/tbv3/tbv3.conf gsm_info operator');

?>

<?php 
	// include header html dan menu navigasi
	include 'head-nav.php';
?>
<div id="content-wrapper">
	<div class="mui--appbar-height"></div>
	<div class="mui-container-fluid">
		
		<h1>Main Configuration Editor</h1>
		<ul class="mui-tabs__bar">
			<li class="mui--is-active"><a data-mui-toggle="tab" data-mui-controls="pane-default-1">Basic Config</a></li>
			<?php
			if (is_dir("/var/web")){
				echo "<li><a data-mui-toggle=\"tab\" data-mui-controls=\"pane-default-2\">Server Config</a></li>";
			}
			?>
			<li><a data-mui-toggle="tab" data-mui-controls="pane-default-3">Advanced Config</a></li>
		</ul>
		<div class="mui-tabs__pane mui--is-active" id="pane-default-1">
			<div class="mui-row">
				<span id="status_process">
				</span>
				<span id="server_message">
				<?php
					if ($_POST["update"]) echo '<pre>Config Updated</pre>';
					else if ($_POST["reload"]) echo '<pre>Config Reloaded</pre>';
					else if ($_POST["default"]) echo '<pre>Config Default</pre>';
					else if (isset($_FILES['uplod'])){
						if(empty($errors)==true) echo '<pre>Config Uploaded</pre>';
						else print_r($errors);
					}
				?>
				</span>
				<div class="mui-col-md-8 mui-col-md-offset-2">
					<legend>Tapping Config</legend>
					<div class="mui-panel mui--bg-color-grey-50">
						<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
						<div class="mui-col-md-3">
							<div class="mui-select">
								<select name="jns_tapping">
									<option value="printer" <?php if($jns_tapping == 'printer'){ echo "selected"; }?>>Printer</option>
									<option value="server" <?php if($jns_tapping == 'server'){ echo "selected"; }?> >Server</option>
								</select>
								<label>Jenis Tapping</label>
							</div>
						</div>
						<div class="mui-col-md-3">
							<div class="mui-textfield mui-textfield--float-label">
								<input type="text" name="dev_id" value="<?php echo $dev_id; ?>">
								<label>Device ID</label>
							</div>
						</div>
						<div class="mui-col-md-6">
							<div class="mui-textfield mui-textfield--float-label">
								<input type="text" name="dev_address" value="<?php echo $address; ?>">
								<label>Device Address</label>
							</div>
						</div>
						<div class="mui-col-md-4">
							<div class="mui-select">
								<select name="dev_timezone">
									<option <?php if($timezone == "Asia/Jakarta"){ echo "selected"; }?> value="Asia/Jakarta" >WIB - Asia/Jakarta</option>
									<option <?php if($timezone == "Asia/Makassar"){ echo "selected"; }?> value="Asia/Makassar">WITA - Asia/Makassar</option>
									<option <?php if($timezone == "Asia/Jayapura"){ echo "selected"; }?> value="Asia/Jayapura">WIT - Asia/Jayapura</option>
								</select>
								<label>TimeZone</label>
							</div>
						</div>
						<div class="mui-col-md-4">
							<div class="mui-textfield mui-textfield--float-label">
								<input type="text" name="dev_lat" value="<?=$latitude;?>" >
								<label>Device Latitude</label>
							</div>
						</div>
						<div class="mui-col-md-4">
							<div class="mui-textfield mui-textfield--float-label">
								<input type="text" name="dev_lon" value="<?=$longitude;?>" >
								<label>Device Latitude</label>
							</div>
						</div>
						<div class="mui-col-md-6">
							<div class="mui-textfield mui-textfield--float-label">
								<input type="text" name="gsm_number" value="<?=$gsm_number;?>" >
								<label>GSM Number</label>
							</div>
						</div>
						<div class="mui-col-md-6 ">
							<div class="mui-select">
								<select name="gsm_apn">
									<option <?php if($gsm_apn == "indosatgprs"){ echo "selected"; }?> value="indosatgprs" >Indosat</option>
									<option <?php if($gsm_apn == "3data"){ echo "selected"; }?> value="3data">3Data</option>
									<option <?php if($gsm_apn == "internet"){ echo "selected"; }?> value="internet">Internet</option>
								</select>
								<label>GSM APN</label>
							</div>
						</div>
					</div>
				</div>
				<div class="mui-col-md-8 mui-col-md-offset-2">
					<legend>Destination Config</legend>
					<div class="mui-panel mui--bg-color-grey-50">
						<div class="mui-col-md-10">
							<div class="mui-textfield mui-textfield--float-label">
								<input type="text" name="server_url" value="<?=$server_url?>">
								<label>Server URL</label>
							</div>
						</div>
						<div class="mui-col-md-2">
							<div class="mui-textfield mui-textfield--float-label">
								<input type="text" name="server_port" value="<?=$server_port?>">
								<label>Port</label>
							</div>
						</div>
						<div class="mui-col-md-6">
							<div class="mui-textfield mui-textfield--float-label">
								<input type="text" name="server_user" value="<?=$server_user?>">
								<label>User</label>
							</div>
						</div>
						<div class="mui-col-md-6">
							<div class="mui-textfield mui-textfield--float-label">
								<input type="text" name="server_pass" value="<?=$server_pass?>">
								<label>Password</label>
							</div>
						</div>
						<div class="mui-col-md-6">
							<div class="mui-textfield mui-textfield--float-label">
								<input type="text" name="server_notif" value="<?=$server_notif[2]?>">
								<label>Server Notification</label>
							</div>
						</div>
					</div>
				</div>
				<div class="mui-col-md-12">
					<button type="submit" class="mui-col-md-8 mui-col-md-offset-2 mui-btn mui-btn--raised mui-btn--primary" name="basic-conf" value="1">Submit</button>
					</form>
				</div>
			</div>
		</div>
		<div class="mui-tabs__pane" id="pane-default-2">
		<?php 
		include("server.php");
		?>
		</div>		
		<div class="mui-tabs__pane" id="pane-default-3">
			<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
			<legend>Advanced Config</legend>
			<div class="row">
				<div class="mui-col-md-12">
					<textarea class="textarealine" cols="80" rows="25" name="textfile" spellcheck="false"><?php Read(); ?></textarea><br>
				</div>
				<div class="mui-col-md-6">
					<input type="submit" class="mui-btn mui-btn--raised mui--bg-color-green-A400" name="update" value="&#128190; Update">
					<input type="submit" class="mui-btn mui-btn--raised mui--bg-color-yellow-300" name="reload" value="&#10227; Reload">
					<input type="submit" class="mui-btn mui-btn--raised mui-btn--primary" name="default" value="Default">
			</form>
				<div class="mui--clearfix"></div>
				<br />
				<div class="mui-panel mui--bg-color-grey-50">
					<legend>Upload Configuration Files</legend>
					<form class="mui-form--inline" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST" enctype="multipart/form-data">
						<div class="mui-textfield">
							<input type="file" name="uplod">
						</div>
						<input type="submit" class="mui-btn mui-btn--raised mui-btn--primary" value="Upload">
					</form>
				</div>
				<div class="mui-panel mui--bg-color-grey-50">
					<legend>Download Configuration Files:</legend>
					<form action="" method="POST" enctype="multipart/form-data">
					<input name="SaveFile" type="submit" class="mui-btn mui-btn--raised mui-btn--primary" value="Download">
					</form>
				</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php 
	// include footer dan javascript
	include 'footer.php';
?>

