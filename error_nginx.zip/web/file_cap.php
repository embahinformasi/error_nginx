<?php
	$page = $_SERVER['PHP_SELF'];
	$sec = "5000";
	$title = "Files Captured";

	if($_GET['folder'] == "raw"){
		$folder = "raw/";
	}elseif($_GET['folder'] == "data"){
		$folder = "data/";
	}else{
		$folder = "archives/";
	}
?>	
<?php include 'head-nav.php'; ?>
<div id="content-wrapper">
	<div class="mui--appbar-height"></div>
	<div class="mui-container-fluid" id="content">
		<div class="mui-row">
			<div class="mui-col-md-12">
				<h1>Files Captured</h1>
				<a href="?folder=raw" class="mui-btn mui-btn--raised mui-btn--primary">RAW</a>
				<a href="?folder=data" class="mui-btn mui-btn--raised mui-btn--primary">DATA</a>
				<a href="?folder=archives" class="mui-btn mui-btn--raised mui-btn--primary">Archives</a>
			</div>
		</div>
		<div class="mui-divider"></div>
		<div class="mui-row">
			<div class="mui-col-md-6">
				<legend><?=strtoupper($folder);?></legend>
				<table class="mui-table mui-table--bordered">
					<thead>
					<tr><th>Filename</th><th>Filesize</th><th>File Modified</th></tr>
					</thead>
					<?					
					$directory = '/var/tbv3/'.$folder;
					foreach (array_reverse(glob($directory."*.bin")) as $filename) {
						$fname = substr($filename, -22);
						echo "<tr><td><a href='http://192.168.1.200/web/files/".$folder.$fname."'>$fname</a></td>";
						echo "<td>" . filesize($filename) . "</td><td>".date ("D, d M Y H:i:s", filemtime($filename))."</td></tr>";
					}
					?>
				</table>
			</div>
		</div>
	</div>
</div>
<?php include 'footer.php'; ?>
