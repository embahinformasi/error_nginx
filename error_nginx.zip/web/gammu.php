<?php
		if($_POST['SaveFile']){
      $file = "/etc/tbv3/gammurc";
      if (file_exists($file)) {
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($file).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        readfile($file);
        exit;
      }
  	}
?>

<!DOCTYPE html>
<html>
  <head>
  </head>
  <title>TappingBoxV3</title>
  <body>
  <body bgcolor="#00FFFF">
  <font face="monospace" color="#000000">
  <A href=home.php>Home</A>
  <A href=setup.php>Setup</A>
  <A href=status.php>Status</A>
  <A href=system.php>System</A>
  <br/>
  <A href=config.php>Config</A>
  <A href=wvdial.php>Wvdial</A>
  <A href=gammu.php>Gammu</A>
  <A href=netconf.php>Network</A>
  <A href=openvpn.php>OpenVPN</A>
  <A href=dns.php>DNS</A>

  <h1>Gammurc Configuration Editor</h1>
	Gammu is used to handle the receive and transmit of the Text Messages (SMS)<br/> 
	<?php
		if(isset($_FILES['uplod'])){
			$errors= array();
			$file_name = $_FILES['uplod']['name'];
			$file_size =$_FILES['uplod']['size'];
			$file_tmp =$_FILES['uplod']['tmp_name'];
			if($file_size > 2097152) $errors[]='File Above 2MB, Too Big!';
			if(empty($errors)==true){
    		$target_file = "/tmp/gammurc.uplod";
    		move_uploaded_file($_FILES['uplod']['tmp_name'], $target_file);
				define("FILE_NAME","$target_file");
			} 
    	else define("FILE_NAME", "/etc/tbv3/gammurc");
		}
		else if ($_POST["default"]) define("FILE_NAME", "/opt/script/gammurc");
    else define("FILE_NAME", "/etc/tbv3/gammurc");
		echo "<h3>Working Files:";echo FILE_NAME;echo "</h3>";

		function Read() {
			echo @file_get_contents(FILE_NAME);
		}
    function Write(){
			$data = $_POST["textfile"];
			@file_put_contents(FILE_NAME, $data);
    }

    if ($_POST["update"]) Write();
	?>     
	
	<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
	<textarea cols="80" rows="15" name="textfile"><?php Read(); ?></textarea><br>
	<input type="submit" name="update" value="Update">
	<input type="submit" name="reload" value="Reload">
	<input type="submit" name="default" value="Default">
	</form>

	Upload Configuration Files:
	<form action="" method="POST" enctype="multipart/form-data">
	<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
	<input type="file" name="uplod">
	<input type="submit" value="Upload">
	</form> 

	Download Configuration Files:
	<form action="" method="POST" enctype="multipart/form-data">
  <input name="SaveFile" type="submit" value="Download">
	</form>

  <?php
    if ($_POST["update"]) echo 'Config Updated';
    else if ($_POST["reload"]) echo 'Config Reloaded';
    else if ($_POST["default"]) echo 'Config Default';
		else if (isset($_FILES['uplod'])){
			if(empty($errors)==true) echo 'Config Uploaded';
			else print_r($errors);
		}
	?>
		
	</font>
	</body>
</html>


