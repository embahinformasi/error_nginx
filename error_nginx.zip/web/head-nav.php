<!doctype html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="refresh" content="<?php echo $sec?>;URL='<?php echo $page?>'">
    <link href="assets/mui.min.css" rel="stylesheet" type="text/css" />
    <title><?php echo $title;?> - TappingBox</title>
    <link href="assets/mui-colors.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/style.css" rel="stylesheet" type="text/css" />
  </head>
  <body>
		<div id="sidedrawer" class="mui--no-user-select mui--bg-color-black-alpha-87 mui--color-white">
			<div id="sidedrawer-brand" class="mui--appbar-line-height">
				<span class="mui--text-title">TappingBox</span>
			</div>
			<div class="mui-divider mui--bg-color-red"></div>
			<ul>
				<li><strong><a href="/web/home.php">Home</a></strong></li>
				<li>
					<strong>Setup</strong>
					<ul>
						<li><a href="config.php">Config</a></li>
						<li><a href="mobile-system.php">Mobile Comunication</a></li>
						<li><a href="networking.php">Networking</a></li>
						<li><a href="openvpn.php">OpenVPN</a></li>
					</ul>
				</li>
				<li>
					<strong>Status</strong>
					<ul>
						<li><a href="tabsysmon.php">Sysmon</a></li>
						<li><a href="notif.php">Notifier</a></li>
						<li><a href="capstat.php">Printer</a></li>
						<li><a href="modem.php">Modem</a></li>
						<li><a href="update.php">Update</a></li>
					</ul>
				</li>
				<li>
					<strong>System</strong>
					<ul>
						<li><a href="admin.php">Admin</a></li>
						<li><a href="file_cap.php">Files</a></li>
						<li><a href="about.php">About</a></li>
					</ul>
				</li>
			</ul>
		</div>
		<header id="header">
			<div class="mui-appbar mui--appbar-line-height mui--bg-color-red-400">
				<div class="mui-container-fluid">
					<a class="sidedrawer-toggle mui--visible-xs-inline-block mui--visible-sm-inline-block js-show-sidedrawer">☰</a>
					<a class="sidedrawer-toggle mui--hidden-xs mui--hidden-sm js-hide-sidedrawer">☰</a>
					<span class="mui--text-title mui--visible-xs-inline-block mui--visible-sm-inline-block">TappingBox</span>
				</div>
			</div>
		</header>
