<!DOCTYPE html>
<?php
	$page = $_SERVER['PHP_SELF'];
	$sec = "5";
?>
<html>
	<head>
	<meta http-equiv="refresh" content="<?php echo $sec?>;URL='<?php echo $page?>'">
	</head>
	<title>TappingBoxV3</title>
	<body>
 	<body bgcolor="#00FFFF">
	<font face="monospace" color="#000000">
	<A href=home.php>Home</A>
	<A href=setup.php>Setup</A>
	<A href=status.php>Status</A>
	<A href=system.php>System</A>
	<!---
	<br/>
	Setup :
	<A href=config.php>Config</A>
	<A href=wvdial.php>Wvdial</A>
	<A href=gammu.php>Gammu</A>
	<A href=netconf.php>Network</A>
	<br/>
	Status :
	<A href=sysmon.php>Sysmon</A>
	<A href=alarm.php>Alarm</A>
	<A href=notif.php>Notifier</A>
	<A href=capstat.php>Printer</A>
	<A href=modem.php>Modem</A>
	<A href=update.php>Update</A>
	<br/>
	System :
	<A href=files/>Files</A>
	<A href=admin.php>Admin</A>
	<A href=about.php>About</A>
	--->

	<h1><t/>TappingBox V3</h1>
	<h2><A href=http://pages.subaga.co.id/>Subaga Mitra Solusi, PT.</A></h2>
  <!-- Griya Agung Block-M3 No.23,<br/> -->
  Jakarta, Indonesia, 2016<br/>
  <a href="mailto:sales@tappingbox.com">sales@tappingbox.com</a>
	<h2>System Info</h2>
  	<?php
			$handle = popen('sudo /opt/script/sysinfo > /tmp/sysinfo.tmp;cat /tmp/sysinfo.tmp', 'r');
    	$read = fread($handle,2048);
 		echo nl2br($read);	
		?>

	<h2>System Summary</h2>
  <table border="1" width="80%"><tr bgcolor="#dddddd"><th>Item</th><th>Value</th>
	</tr><tr><td>Version</td><td>
  <?php
		$handle = popen('A=$(ls /opt/install/.stamp*);echo ${A##*stamp-}', 'r');
    $read = fread($handle,16);
		echo "$read";
	?>
	</td></tr><tr><td>Date</td><td>
	<?php	
	 	$handle = popen('date', 'r');
    $read = fread($handle,32);
		echo "$read";
	?>
	</td></tr><tr><td>System Up Time</td><td>
	<?php
		$handle = popen('/opt/script/calcuptime | sudo tee /tmp/tbv3/uptime >> /dev/null', 'r');
    $read = fread($handle,16);
		pclose($handle);
	  $A=(file_get_contents('/tmp/tbv3/uptime'));echo "$A";
	?>
	</td></tr><tr><td>Device id</td><td>
	<?php
	 	$handle = popen('/opt/tbexec/getvalue /etc/tbv3/tbv3.conf device id', 'r');
    $read = fread($handle,32);
		echo "$read";
	?>
	</td></tr><tr><td>Capture type</td><td>
	<?php
	 	$handle = popen("/opt/tbexec/getvalue /etc/tbv3/tbv3.conf tapping printer | tr -d '\t\r\n'", 'r');
    $read = fread($handle,32);
		if ($read == "1") {echo "Printer";}  else  {echo "Server";}
	?>
	</td></tr><tr><td>Address</td><td>
	<?php
	 	$handle = popen('/opt/tbexec/getvalue /etc/tbv3/tbv3.conf device address', 'r');
    $read = fread($handle,32);
		echo "$read";
	?>
	</td></tr><tr><td>Location</td><td>
	<?php
	 	$handle = popen("/opt/tbexec/getvalue /etc/tbv3/tbv3.conf device latitude|tr -d '\t\r\n'", 'r');
    $lat = fread($handle,32);
	 	$handle = popen("/opt/tbexec/getvalue /etc/tbv3/tbv3.conf device longitude | tr -d '\t\r\n'", 'r');
    $lon = fread($handle,32);
		echo "<A href=http://maps.google.com/maps?q=$lat,$lon>http://maps.google.com/maps?q=$lat,$lon</A>";
	?>
	</td></table>

  <h2>Printer Data</h2>
  <table border="1" width="80%"><tr bgcolor="#dddddd"><th>Item</th><th>Value</th>
	</td></tr><tr><td>Captured Data</td><td>
		<?php>$A=(file_get_contents('/var/runtbv3/statistic/new'));echo "$A"; ?><br/>
	</td></tr><tr><td>Processed Data</td><td>
		<?php>$A=(file_get_contents('/var/runtbv3/statistic/processed'));echo "$A"; ?><br/>
	</td></tr><tr><td>Uploaded Data</td><td>
		<?php>$A=(file_get_contents('/var/runtbv3/statistic/send'));echo "$A"; ?><br/>
	</td></table>

  <h2>Event Alarm:</h2>
  <?php
    $handle = popen('tail /var/log/tbv3/tbnotifierd.alarm.log 2>&1', 'r');
    $read = fread($handle, 2048);
    echo nl2br($read);
    pclose($handle);
  ?>

	</font>
	</body>
</html>
