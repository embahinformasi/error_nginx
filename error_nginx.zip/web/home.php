<?php
	$page = $_SERVER['PHP_SELF'];
	$sec = "5000";
	$title = "Home";
	$current_url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
?>

<?php include 'head-nav.php'; ?>
<div id="content-wrapper">
	<div class="mui--appbar-height"></div>
	<div class="mui-container-fluid" id="content">
	<div id="Reload">
		<div class="mui-row">
			<div class="mui-col-md-6">
				<h2>System Info</h2>
			<?php
				$handle = popen('sudo /opt/script/sysinfo > /tmp/sysinfo.tmp;cat /tmp/sysinfo.tmp', 'r');
				$read = fread($handle,2048);
				echo $read;
			?>
			</div>
			<div class="mui-col-md-6">
				<h2>System Summary</h2>
				<table class="mui-table mui-table--bordered">
					<tr bgcolor="#dddddd"><th>Item</th><th>Value</th>
				</tr><tr><td>Version</td><td>
				<?php
					$handle = popen('A=$(ls /opt/install/.stamp*);echo ${A##*stamp-}', 'r');
					$read = fread($handle,16);
					echo "$read";
				?>
				</td></tr><tr><td>Date</td><td>
					<div id="streamTitle"><div id="streamTitleCaption">
				<?php	
					$handle = popen('date', 'r');
					$read = fread($handle,32);
					echo "$read";
				?>
				</div>
				</div>
				</td></tr><tr><td>System Up Time</td><td>
				<?php
					$handle = popen('/opt/script/calcuptime | sudo tee /tmp/tbv3/uptime >> /dev/null', 'r');
					$read = fread($handle,16);
					pclose($handle);
					$A=(file_get_contents('/tmp/tbv3/uptime'));echo "$A";
				?>
				</td></tr><tr><td>Device id</td><td>
				<?php
					$handle = popen('/opt/tbexec/getvalue /etc/tbv3/tbv3.conf device id', 'r');
					$read = fread($handle,32);
					echo "$read";
				?>
				</td></tr><tr><td>Capture type</td><td>
				<?php
					$handle = popen("/opt/tbexec/getvalue /etc/tbv3/tbv3.conf tapping printer | tr -d '\t\r\n'", 'r');
					$read = fread($handle,32);
					if ($read == "1") {echo "Printer";}  else  {echo "Server";}
				?>
				</td></tr><tr><td>Address</td><td>
				<?php
					$handle = popen('/opt/tbexec/getvalue /etc/tbv3/tbv3.conf device address', 'r');
					$read = fread($handle,32);
					echo "$read";
				?>
				</td></tr><tr><td>Location</td><td>
				<?php
					$handle = popen("/opt/tbexec/getvalue /etc/tbv3/tbv3.conf device latitude|tr -d '\t\r\n'", 'r');
					$lat = fread($handle,32);
					$handle = popen("/opt/tbexec/getvalue /etc/tbv3/tbv3.conf device longitude | tr -d '\t\r\n'", 'r');
					$lon = fread($handle,32);
					echo "<A href=http://maps.google.com/maps?q=$lat,$lon>http://maps.google.com/maps?q=$lat,$lon</A>";
				?>
				</td></table>
			</div>
			<div class="mui-col-md-6">
				<h2>Printer Data</h2>
				<table class="mui-table mui-table--bordered">
					<tr bgcolor="#dddddd"><th>Item</th><th>Value</th>
				</td></tr><tr><td>Captured Data</td><td>
					<?php>$A=(file_get_contents('/var/runtbv3/statistic/new'));echo "$A"; ?><br/>
				</td></tr><tr><td>Processed Data</td><td>
					<?php>$A=(file_get_contents('/var/runtbv3/statistic/processed'));echo "$A"; ?><br/>
				</td></tr><tr><td>Uploaded Data</td><td>
					<?php>$A=(file_get_contents('/var/runtbv3/statistic/send'));echo "$A"; ?><br/>
				</td></table>
			</div>
			<div class="mui-col-md-6">
				<h2>Event Alarm:</h2>
				<?php
					$handle = popen('tail /var/log/tbv3/tbnotifierd.alarm.log 2>&1', 'r');
					$read = fread($handle, 2048);
					echo nl2br($read);
					//var_dump($read);
					pclose($handle);
				?>
			</div>
		</div>
	</div>
	</div>
</div>
<script>
/**
 * Refresh content Home dan status
 **/
var current_url = document.location;
function updateContent() {
		$("#content").load("<?echo "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";?> #Reload"); 
}
setInterval(updateContent, 15000); // 15 detik | 1000 = 1 dtk
</script>
<?php include 'footer.php'; ?>
