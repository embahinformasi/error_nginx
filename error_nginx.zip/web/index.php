<!DOCTYPE html>
<?php
$page = $_SERVER['PHP_SELF'];
$sec = "0";
?>
<html>
  <head>
	<title>TappingBoxV3</title>
  <meta http-equiv="refresh" content="<?php echo $sec?>;URL=home.php">
	</head>
</html>
