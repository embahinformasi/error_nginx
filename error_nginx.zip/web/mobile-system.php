<?php
	$title = "Mobile Comunication";
	
	/*
	 * WVDial action
	 * 
	 * Download konfigurasi File
	 */
	if($_POST['SaveFileWVdial']){
		$file = "/etc/tbv3/wvdial.conf";
		if (file_exists($file)) {
			header('Content-Type: application/octet-stream');
			header('Content-Disposition: attachment; filename="'.basename($file).'"');
			header('Expires: 0');
			header('Cache-Control: must-revalidate');
			header('Pragma: public');
			header('Content-Length: ' . filesize($file));
			readfile($file);
			exit;
		}
	}
	
	/*
   * Update, Reload, Default, Upload config
   */
  // Upload file config
	if(isset($_FILES['uplod-wvdial'])){
			$errors= array();
			$file_name = $_FILES['uplod-wvdial']['name'];
			$file_size =$_FILES['uplod-wvdial']['size'];
			$file_tmp =$_FILES['uplod-wvdial']['tmp_name'];
			if($file_size > 2097152) $errors[]='File Above 2MB, Too Big!';
			if(empty($errors)==true){
    		$target_file = "/tmp/wvdial.conf";
    		move_uploaded_file($_FILES['uplod-wvdial']['tmp_name'], $target_file);
				define("FILE_NAME","$target_file");
			} 
    	else define("FILE_NAME", "/etc/tbv3/wvdial.conf");
		}
		// Restore Default config
		else if ($_POST["default-wvdial"]) define("FILE_NAME", "/opt/script/wvdial.conf");
    else define("FILE_NAME", "/etc/tbv3/wvdial.conf");
		//echo "<h3>Working Files:";echo FILE_NAME;echo "</h3>";

		function Read_wvdial() {
			echo @file_get_contents(FILE_NAME);
		}
		// Update configuration
    function Write_wvdial(){
			$data = $_POST["wvdial-file"];
			@file_put_contents(FILE_NAME, $data);
    }

	if ($_POST["update-wvdial"]) Write_wvdial();
    
    /*
	 * Gammu action
	 * 
	 * Download konfigurasi File
	 */
	if($_POST['SaveFileGammu']){
		$file = "/etc/tbv3/gammurc";
		if (file_exists($file)) {
			header('Content-Type: application/octet-stream');
			header('Content-Disposition: attachment; filename="'.basename($file).'"');
			header('Expires: 0');
			header('Cache-Control: must-revalidate');
			header('Pragma: public');
			header('Content-Length: ' . filesize($file));
			readfile($file);
			exit;
		}
	}
	
	/*
   * Update, Reload, Default, Upload config gammu
   */
  // Upload file config
	if(isset($_FILES['uplod-gammu'])){
			$errors= array();
			$file_name = $_FILES['uplod-gammu']['name'];
			$file_size =$_FILES['uplod-gammu']['size'];
			$file_tmp =$_FILES['uplod-gammu']['tmp_name'];
			if($file_size > 2097152) $errors[]='File Above 2MB, Too Big!';
			if(empty($errors)==true){
    		$target_file = "/tmp/gammurc.uplod";
    		move_uploaded_file($_FILES['uplod-gammu']['tmp_name'], $target_file);
				define("FILE_NAMES","$target_file");
			} 
    	else define("FILE_NAMES", "/etc/tbv3/gammurc");
		}
		// Restore Default config
		else if ($_POST["default-gammu"]) define("FILE_NAMES", "/opt/script/gammurc");
    else define("FILE_NAMES", "/etc/tbv3/gammurc");
		//echo "<h3>Working Files:";echo FILE_NAME;echo "</h3>";

		function Read_gammu() {
			echo @file_get_contents(FILE_NAMES);
		}
		// Update configuration
    function Write_gammu(){
			//$data = $_POST["wvdial-gammu"];
			$data = $_POST["gammu-file"];
			@file_put_contents(FILE_NAMES, $data);
    }

	if ($_POST["update-gammu"]) Write_gammu();
?>

<?php include 'head-nav.php'; ?>
<div id="content-wrapper">
	<div class="mui--appbar-height"></div>
	<div class="mui-container-fluid">
		<?php
    if ($_POST["update"]) echo 'Config Updated';
    else if ($_POST["reload"]) echo 'Config Reloaded';
    else if ($_POST["default"]) echo 'Config Default';
		else if (isset($_FILES['uplod'])){
			if(empty($errors)==true) echo 'Config Uploaded';
			else print_r($errors);
		}
	?>
		<div class="mui-row">
			<div class="mui-col-md-12">
				<legend>WVDial Config</legend>
				WVDIAL is used to make dial-up connection throught modem 3G/HSDPA.<br/>
				You can edit or add option of data connection setting here,<br/>
				prior to GSM provider that the sims card is coming from.<br/>
			</div>
			<div class="mui-col-md-6">
				<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
				<textarea rows="15" name="wvdial-file" class="textarealine"><?php Read_wvdial(); ?></textarea>
				<div class="mui--text-center" style="margin:-20px 0 16px ;">
					<input type="submit" class="mui-btn mui-btn--small mui-btn--raised mui--bg-color-green-A400" name="update-wvdial" value="Update">
					<input type="submit" class="mui-btn mui-btn--small mui-btn--raised mui--bg-color-yellow-300" name="reload-wvdial" value="Reload">
					<input type="submit" class="mui-btn mui-btn--small mui-btn--raised mui-btn--primary" name="default-wvdial" value="Default">
				</div>
				</form>
			</div>
			<div class="mui-col-md-6">
				
				<div class="mui--clearfix"></div><br />
				<div class="mui-panel mui--bg-color-grey-50">
					Upload Configuration Files:
					<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST" enctype="multipart/form-data">
					<input type="file" name="uplod-wvdial">
					<input type="submit" class="mui-btn mui-btn--raised mui-btn--primary" name="upload-wvdial" value="Upload">
					</form> 
				</div>
				<div class="mui-panel mui--bg-color-grey-50">
					Download Configuration Files:
					<form action="" method="POST" enctype="multipart/form-data">
					<input name="SaveFileWVdial" type="submit" class="mui-btn mui-btn--raised mui-btn--primary" value="Download">
					</form>
				</div>
			</div>
		</div>
		<div class="mui-divider"></div>
		<div class="mui-row">
			<div class="mui-col-md-12">
				<legend>Gammu Config</legend>
				Gammu is used to handle the receive and transmit of the Text Messages (SMS)<br/>
			</div>
			<div class="mui-col-md-6">
				<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
				<textarea rows="15" name="gammu-file" class="textarealine"><?php Read_gammu(); ?></textarea>
				<div class="mui--text-center" style="margin:-20px 0 16px ;">
					<input type="submit" class="mui-btn mui-btn--small mui-btn--raised mui--bg-color-green-A400" name="update-gammu" value="Update">
					<input type="submit" class="mui-btn mui-btn--small mui-btn--raised mui--bg-color-yellow-300" name="reload-gammu" value="Reload">
					<input type="submit" class="mui-btn mui-btn--small mui-btn--raised mui-btn--primary" name="default-gammu" value="Default">
					</form>
				</div>
			</div>
			<div class="mui-col-md-6">
				<div class="mui-panel mui--bg-color-grey-50">
					Upload Configuration Files:
					<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST" enctype="multipart/form-data">
					<input type="file" name="uplod-gammu">
					<input type="submit" class="mui-btn mui-btn--raised mui-btn--primary" name="upload-gammu" value="Upload">
					</form> 
				</div>
				<div class="mui-panel mui--bg-color-grey-50">
					Download Configuration Files:
					<form action="" method="POST" enctype="multipart/form-data">
					<input name="SaveFileGammu" type="submit" class="mui-btn mui-btn--raised mui-btn--primary" value="Download">
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include 'footer.php'; ?>
