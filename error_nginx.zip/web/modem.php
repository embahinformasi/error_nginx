<?php
	$page = $_SERVER['PHP_SELF'];
	$sec = "6000";
	$title = "Modem Status";
	
	if (isset($_POST['btrestart'])){exec('sudo /opt/tbexec/restart /opt/tbexec/tbmodctrld');}
?>

<?php include 'head-nav.php'; ?>
<div id="content-wrapper">
	<div class="mui--appbar-height"></div>
	<div class="mui-container-fluid" id="content">
	<div id="Reload">
		<div class="mui-row">
			<div class="mui-col-md-12">
				<h1>Modem Status</h1>
				<div class="mui--text-center">		
				<?php
					if (file_exists('/tmp/tbv3/.tbmodctrld')==TRUE) {
						$status=1;
						echo "<button class='mui-btn mui-btn--raised mui--bg-color-green-A400 sys-lbl'>Service Modem is running</button>";
					}else{
						$status=0;
						echo "<button class='mui-btn mui-btn--raised mui-btn--danger sys-lbl'>Service Modem is stopped</button>";
					}
				?>
				</div>
			<form method="post">
				<button name="btrestart" class="mui-btn mui-btn--raised mui-btn--primary mui--pull-right">Restart</button>
			</form>
			</div>
		</div>
		<div class="mui-row">
			<div class="mui-col-md-6">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend class="mui--divider-bottom">Bandwidth</legend>
				<h3>
				<?php
					$A=file_get_contents('/tmp/tbv3/stbw');
					echo nl2br($A);
					echo("<title>$A</title>");
				?>
				</h3>
				</div>
			</div>
<div class="mui-col-md-6">
  <div class="mui-panel mui--bg-color-grey-50">
    <legend class="mui--divider-bottom">SIM INFO</legend>
      <?php
        $A=file_get_contents('/tmp/tbv3/modem/cfun');
        echo "CFUN: ";echo nl2br($A);
        $A=file_get_contents('/tmp/tbv3/modem/cpin');
        echo "CPIN: ";echo nl2br($A);
        $A=file_get_contents('/tmp/tbv3/modem/creg');
        echo "CREG: ";echo nl2br($A);
        $A=file_get_contents('/tmp/tbv3/modem/cops');
        echo "COPS: ";echo nl2br($A);
        $A=file_get_contents('/tmp/tbv3/objmon/sigmodem');
        echo "CSQ: ";echo nl2br($A);
     ?>
  </div>
</div>
			<div class="mui-col-md-6">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend class="mui--divider-bottom">SMS Service Status</legend>
					<?php
					if ( $status == 1 ) {
						/* Add redirection so we can get stderr. */
						$handle = popen('tail /var/log/tbv3/tbsmservice.log 2>&1', 'r');
						$read = fread($handle, 2048);	
						echo nl2br($read);
						pclose($handle);
					}
					?>					
				</div>
			</div>
    </div>
    <div class="mui-row">
			<div class="mui-col-md-6">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend class="mui--divider-bottom">Modem Control Status</legend>
					<?php
						$handle = popen('tail /var/log/tbv3/tbmodctrld.log 2>&1', 'r');
						$read = fread($handle, 2048);	
						echo nl2br($read);
						pclose($handle);
					?>
				</div>
			</div>
			<div class="mui-col-md-6">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend class="mui--divider-bottom">WVDial Status</legend>
					<?php		
					if ( $status == 1) {
						/* add redirection so we can get stderr. */
						$handle = popen('tail /var/log/tbv3/wvdial.log 2>&1', 'r');
						$read = fread($handle, 2048);
						echo nl2br($read);
						pclose($handle);
					}
					?>
				</div>
			</div>
		</div>
  </div>
	</div>
</div>
<script>
/**
 * Refresh content Home dan status
 **/
var current_url = document.location;
function updateContent() {
		$("#content").load("<?echo "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";?> #Reload"); 
}
setInterval(updateContent, 15000); // 15 detik | 1000 = 1 dtk
</script>
<?php include 'footer.php'; ?>
