<?php
    if($_POST['SaveFile']){
      $file = "/etc/network/interfaces";
      if (file_exists($file)) {
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($file).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        readfile($file);
        exit;
      }
  	}
		else if (isset($_POST['survey'])){
			exec('sudo /opt/script/sitesurvey');
      define("FILE_NAME", "/etc/network/interfaces");
		}else if(isset($_FILES['uplod'])){
			$errors= array();
			$file_name = $_FILES['uplod']['name'];
			$file_size =$_FILES['uplod']['size'];
			$file_tmp =$_FILES['uplod']['tmp_name'];
			if($file_size > 2097152) $errors[]='File Above 2MB, Too Big!';
			if(empty($errors)==true){
				exec ('[[ -d /tmp/www ]] || { sudo mkdir -p /tmp/www;sudo chmod 0777 /tmp/www; }');
    		$target_file = "/tmp/www/interfaces";
    		move_uploaded_file($_FILES['uplod']['tmp_name'], $target_file);
				define("FILE_NAME","$target_file");
			} 
			else define("FILE_NAME", "/etc/network/interfaces");
		} 
		else if ($_POST["default"]){
			define("FILE_NAME", "/opt/script/interfaces");
		} 
		else if (isset($_POST['wificon'])){
			$ssid=$_POST["ssid"];
			$key=$_POST["key"];
			$encrypt=$_POST["encrypt"];
			//echo "wificon:$ssid,$key,$encrypt<br/>";
    	$target_dir = "/tmp/www";
    	$target_file = "/tmp/www/interfaces";
			exec ("[[ -d $target_dir ]] || { sudo mkdir -p /tmp/www;sudo chmod 0777 /tmp/www; }");
			exec ("cp -f /etc/network/interfaces $target_file");
      if("$encrypt" == "open" && empty($ssid)==false) {
				exec ("echo \"\nallow-hotplug wlan0\" | sudo tee -a $target_file");
				exec ("echo \"iface wlan0 inet dhcp\" | sudo tee -a $target_file");
				exec ("echo \"\twireless-essid $ssid\" | sudo tee -a $target_file");
				//exec ("echo \"\twireless-key\" | sudo tee -a $target_file");
				define("FILE_NAME","$target_file");
      }else if("$encrypt" == "wep" && empty($ssid)==false && empty($key)==false) {
				exec ("echo \"\nallow-hotplug wlan0\" | sudo tee -a $target_file");
				exec ("echo \"iface wlan0 inet dhcp\" | sudo tee -a $target_file");
				exec ("echo \"\twireless-essid $ssid\" | sudo tee -a $target_file");
				exec ("echo \"\twireless-key $key\" | sudo tee -a $target_file");
				define("FILE_NAME","$target_file");
      }else if("$encrypt" == "wpa" && empty($ssid)==false && empty($key)==false) {
				exec ("echo \"\nallow-hotplug wlan0\" | sudo tee -a $target_file");
				exec ("echo \"iface wlan0 inet dhcp\" | sudo tee -a $target_file");
				exec ("sudo /opt/script/inwpapass $ssid $key $target_file");

				define("FILE_NAME","$target_file");
			}else define("FILE_NAME", "/etc/network/interfaces");
    } else define("FILE_NAME", "/etc/network/interfaces");
		
		function Read() {
			echo @file_get_contents(FILE_NAME);
		}
    function Write(){
			$data = $_POST["textfile"];
			@file_put_contents(FILE_NAME, $data);
    }

    if ($_POST["update"]) Write();
?>

<!DOCTYPE html>
<html>
  <head>
  </head>
  <title>TappingBoxV3</title>
  <body>
  <body bgcolor="#00FFFF">
  <font face="monospace" color="#000000">
  <A href=home.php>Home</A>
  <A href=setup.php>Setup</A>
  <A href=status.php>Status</A>
  <A href=system.php>System</A>
  <br/>
  <A href=config.php>Config</A>
  <A href=wvdial.php>Wvdial</A>
  <A href=gammu.php>Gammu</A>
  <A href=netconf.php>Network</A>
  <A href=openvpn.php>OpenVPN</A>
  <A href=dns.php>DNS</A>

  <h1>Network Interfaces Editor</h1>
	Using traditional "ifup" via network interfaces<br/>
	Use the option pre-up, post-up, pre-down & post-down followed by shell script to customize network configuration	

	<h3><?php	echo "Working Files:";echo FILE_NAME; ?></h3>

	<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
	<textarea cols="80" rows="15" name="textfile"><?php Read(); ?></textarea><br>
	<input type="submit" name="update" value="Update">
	<input type="submit" name="reload" value="Reload">
	<input type="submit" name="default" value="Default">
	</form>

	Upload Configuration Files:
	<form action="" method="POST" enctype="multipart/form-data">
	<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
	<input type="file" name="uplod">
	<input type="submit" value="Upload">
	</form> 

	Download Configuration Files:
	<form action="" method="POST" enctype="multipart/form-data">
  <input name="SaveFile" type="submit" value="Download">
	</form>

  <?php
    if ($_POST["update"]) echo 'Config Updated';
    else if ($_POST["reload"]) echo 'Config Reloaded';
    else if ($_POST["default"]) echo 'Config Default';
		else if (isset($_FILES['uplod'])){
			if(empty($errors)==true) echo 'Config Uploaded';
			else print_r($errors);
		}
	?>

	<h2>Wireless Site Survey</h2>
	<?php
		if (isset($_POST['survey'])){
			$A=file_get_contents('/tmp/tbv3/www/sitesurvey.tmp');
			echo nl2br($A);
		}
	?>
	<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
	<input type="submit" name="survey" value="Scan">     
	</form> 
	
	<h2>Wireless Client Config Generator</h2>
	<!---<form action="" method="post">--->
	<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
		ESSID: <input type="text" name="ssid" value="<?php echo $ssid; ?>"><br/>
		KEY: <input type="text" name="key" value="<?php echo $key; ?>"><br/>
		Encryption:
		<select name="encrypt">
			<option value="<?php echo $encrypt; ?>"><?php echo $encrypt; ?></option>
			<option value="open">open</option>
			<option value="wep">wep</option>
			<option value="wpa">wpa</option>
		</select>
	<input type="submit" name="wificon" value="Submit">     
	</form> 

	<!---	<?php
		if (isset($_POST['wificon'])){
			if(empty($_POST['ssid'])==false){
				echo "ESSID=".$_POST['encrypt'];echo "<br/>"; }
			if(empty($_POST['key'])==false){
				echo "KEY=".$_POST['key'];echo "<br/>"; }
			if(empty($_POST['encrypt'])==false){
				echo "ENCRYPT=".$_POST['encrypt'];echo "<br/>";}
		}
	?> --->
	
	</font>
	</body>
</html>


