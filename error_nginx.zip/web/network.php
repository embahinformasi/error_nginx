<!DOCTYPE html>
<?php
	//$page = $_SERVER['PHP_SELF'];$sec = "5";
	$tmpdir="/tmp/tbv3/www";
	exec ("[[ -d $tmpdir ]]||{ sudo mkdir -p $tmpdir;sudo chmod 0777 $tmpdir; } ");
	if(isset($_POST['ping'])){
		$destip=$_POST["destip"];
		$interface=$_POST["interface"];
		if(empty($interface)){
			exec("ping -c 3 $destip|grep loss>$tmpdir/resping");
			$resping=file_get_contents("$tmpdir/resping");
		}else{
			exec("ping -c 3 -I $interface $destip|grep loss >$tmpdir/resping");
			$resping=file_get_contents("$tmpdir/resping");
		}
	}
	
?>
<html>
  <head>
	<title>TappingBoxV3</title>
  <!---<meta http-equiv="refresh" content="<?php echo $sec?>;URL=network.php">--->
	</head>
  <title>TappingBoxV3</title>
  <body>
  <body bgcolor="#00FFFF">
  <font face="monospace" color="#000000">
  <A href=home.php>Home</A>
  <A href=setup.php>Setup</A>
  <A href=status.php>Status</A>
  <A href=system.php>System</A>
	<br/>
  <A href=tabsysmon.php>Sysmon</A>
  <A href=notif.php>Notifier</A>
  <A href=capstat.php>Printer</A>
  <A href=modem.php>Modem</A>
  <A href=update.php>Update</A>
  <A href=network.php>Network</A>

	<h1>Networking Status</h1>
	<h2>Test Ping</h2>
  <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
    Destination: <input type="text" name="destip" value="<?php echo $destip; ?>"><br/>
    <!---Source: <input type="text" name="source" value="<?php echo $sourceip; ?>"><br/>--->
		Interface: 
		<select name="interface">
		<?php
      if(empty($interface)==false)echo "<option value=\"$interface\">$interface</option>";
      echo "<option value=\"\">Auto</option>";
			exec ("ls /sys/class/net | tee $tmpdir/IF");
      $i=1;
      for(;;){
        $handle = popen("sed \"{$i}q;d\" $tmpdir/IF|tr -d '\t\r\n'", 'r');
        $read = fread($handle,16);
        pclose($handle);
        if(empty($read))break;
        if($read!="lo" && $read!="tunl0" && $read!="wwan0"){
          echo "<option value=\"$read\">$read</option>";
        }
        $i++;
      }
		?>
		</select><br>	
    <input type="submit" name="ping" value="Ping">
  </form>
	<?php
		if(isset($_POST['ping'])){
			if(empty($resping)==false){
				echo "Ping Result: $resping<br>";
			}
		}
	?>


  <?php
		exec ("/opt/script/netstat > $tmpdir/netstat 2>&1");
		$MSG=(file_get_contents("$tmpdir/netstat"));
    echo nl2br($MSG);
  ?>

	</font>
	</body>
</html>
