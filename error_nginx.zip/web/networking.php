<?php
	$title = "Network Config";
	
	/*
	 * Networking action
	 * 
	 * Download konfigurasi File
	 */
    if($_POST['SaveFileNet']){
      $file = "/etc/network/interfaces";
      if (file_exists($file)) {
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($file).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($file));
        readfile($file);
        exit;
      }
  	}
  	// Scan wireless available
		else if (isset($_POST['survey'])){
			exec('sudo /opt/script/sitesurvey');
      define("FILE_NAME", "/etc/network/interfaces");
		}
		/*
		 * Update, Reload, Default, Upload config
		 */
		// Upload file config
			else if(isset($_FILES['uplod-net'])){
			$errors= array();
			$file_name = $_FILES['uplod-net']['name'];
			$file_size =$_FILES['uplod-net']['size'];
			$file_tmp =$_FILES['uplod-net']['tmp_name'];
			if($file_size > 2097152) $errors[]='File Above 2MB, Too Big!';
			if(empty($errors)==true){
				exec ('[[ -d /tmp/www ]] || { sudo mkdir -p /tmp/www;sudo chmod 0777 /tmp/www; }');
    		$target_file = "/tmp/www/interfaces";
    		move_uploaded_file($_FILES['uplod-net']['tmp_name'], $target_file);
				define("FILE_NAME","$target_file");
			} 
			else define("FILE_NAME", "/etc/network/interfaces");
		}
		// Restore Default config
		else if ($_POST["default-net"]){
			define("FILE_NAME", "/opt/script/interfaces");
		} 
		else if (isset($_POST['wificon'])){
			$ssid=$_POST["ssid"];
			$key=$_POST["key"];
			$encrypt=$_POST["encrypt"];
			//echo "wificon:$ssid,$key,$encrypt<br/>";
    	$target_dir = "/tmp/www";
    	$target_file = "/tmp/www/interfaces";
			exec ("[[ -d $target_dir ]] || { sudo mkdir -p /tmp/www;sudo chmod 0777 /tmp/www; }");
			exec ("cp -f /etc/network/interfaces $target_file");
      if("$encrypt" == "open" && empty($ssid)==false) {
				exec ("echo \"\nallow-hotplug wlan0\" | sudo tee -a $target_file");
				exec ("echo \"iface wlan0 inet dhcp\" | sudo tee -a $target_file");
				exec ("echo \"\twireless-essid $ssid\" | sudo tee -a $target_file");
				//exec ("echo \"\twireless-key\" | sudo tee -a $target_file");
				define("FILE_NAME","$target_file");
      }else if("$encrypt" == "wep" && empty($ssid)==false && empty($key)==false) {
				exec ("echo \"\nallow-hotplug wlan0\" | sudo tee -a $target_file");
				exec ("echo \"iface wlan0 inet dhcp\" | sudo tee -a $target_file");
				exec ("echo \"\twireless-essid $ssid\" | sudo tee -a $target_file");
				exec ("echo \"\twireless-key $key\" | sudo tee -a $target_file");
				define("FILE_NAME","$target_file");
      }else if("$encrypt" == "wpa" && empty($ssid)==false && empty($key)==false) {
				exec ("echo \"\nallow-hotplug wlan0\" | sudo tee -a $target_file");
				exec ("echo \"iface wlan0 inet dhcp\" | sudo tee -a $target_file");
				exec ("sudo /opt/script/inwpapass $ssid $key $target_file");

				define("FILE_NAME","$target_file");
			}else define("FILE_NAME", "/etc/network/interfaces");
    } else define("FILE_NAME", "/etc/network/interfaces");
		
		function Read_net() {
			echo @file_get_contents(FILE_NAME);
		}
		// Update configuration
    function Write_net(){
			$data = $_POST["net-file"];
			@file_put_contents(FILE_NAME, $data);
    }
    if ($_POST["update-net"]) Write_net();
    
		/**
		* DNS action
		* 
		* Download konfigurasi File
		**/
		if($_POST['SaveFileDNS']){
			$file = "/etc/resolv.conf";
			if (file_exists($file)) {
				header('Content-Type: application/octet-stream');
				header('Content-Disposition: attachment; filename="'.basename($file).'"');
				header('Expires: 0');
				header('Cache-Control: must-revalidate');
				header('Pragma: public');
				header('Content-Length: ' . filesize($file));
				readfile($file);
				exit;
			}
		}
		
		/**
		* Lock/Unlock DNS
		**/
		$target_dir="/tmp/www";
		exec("[[ -d $target_dir ]] || { sudo mkdir -p $target_dir;sudo chmod 0777 $target_dir; } ");
		if(isset($_POST['persist'])){
			if($_POST["locked"]=="1"){
				exec('sudo /opt/script/immutflag /etc/resolv.conf set');
			}else{
				exec('sudo /opt/script/immutflag /etc/resolv.conf reset');
			}
		} 
		exec ("/opt/script/immutflag /etc/resolv.conf | sudo tee $target_dir/ifresolv");
		$locked=file_get_contents("/$target_dir/ifresolv");
		if($locked == "1\n")$locked="1";else $locked="0";
		
		/**
		 * 
		 * Update, Reload, Default, Upload config
		 * 
		 **/
		if(isset($_FILES['uplod-dns'])){
			$errors= array();
			$file_name = $_FILES['uplod-dns']['name'];
			$file_size =$_FILES['uplod-dns']['size'];
			$file_tmp =$_FILES['uplod-dns']['tmp_name'];
			if($file_size > 2097152) $errors[]='File Above 2MB, Too Big!';
			if(empty($errors)==true){
    		$target_file = $target_dir . "resolv.conf";
    		move_uploaded_file($_FILES['uplod-dns']['tmp_name'], $target_file);
				define("FILE_NAMES","$target_file");
			} 
    	else define("FILE_NAMES", "/etc/resolv.conf");
		}
		else if ($_POST["default"]) define("FILE_NAMES", "/opt/script/resolv.conf");
    else define("FILE_NAMES", "/etc/resolv.conf");
		//echo "<h3>Working Files:";echo FILE_NAME;echo "</h3>";

		function Read_DNS() {
			echo @file_get_contents(FILE_NAMES);
		}
    function Write_DNS(){
			exec('sudo chmod 0777 /etc/resolv.conf');
			$data = $_POST["dns-file"];
			@file_put_contents(FILE_NAMES, $data);
    }

    if ($_POST["update-dns"]) Write_DNS();
?>
<?php include 'head-nav.php'; ?>
<div id="content-wrapper">
	<div class="mui--appbar-height"></div>
	<div class="mui-container-fluid">
		<?php
    if ($_POST["update-net"]) echo 'Config Updated';
    else if ($_POST["reload-net"]) echo 'Config Reloaded';
    else if ($_POST["default-net"]) echo 'Config Default';
		else if (isset($_FILES['uplod-net'])){
			if(empty($errors)==true) echo 'Config Uploaded';
			else print_r($errors);
		}
		?>
		<div class="mui-row">
			<div class="mui-col-md-12">
				<legend>Network Interfaces Editor</legend>
				Using traditional "ifup" via network interfaces<br/>
				Use the option pre-up, post-up, pre-down & post-down followed by shell script to customize network configuration
			</div>
			<div class="mui-col-md-6">
				<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
				<textarea class="textarealine" rows="15" name="net-file"><?php Read_net(); ?></textarea>
				<div class="mui--text-center" style="margin:-20px 0 16px ;">
					<input type="submit" class="mui-btn mui-btn--small mui-btn--raised mui--bg-color-green-A400" name="update-net" value="Update">
					<input type="submit" class="mui-btn mui-btn--small mui-btn--raised mui--bg-color-yellow-300" name="reload-net" value="Reload">
					<input type="submit" class="mui-btn mui-btn--small mui-btn--raised mui-btn--primary" name="default-net" value="Default">
				</div>
				</form>
			</div>
			<div class="mui-col-md-6">
				<div class="mui--clearfix"></div><br />
				<div class="mui-panel mui--bg-color-grey-50">
					Upload Configuration Files:
					<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST" enctype="multipart/form-data">
					<input type="file" name="uplod-net">
					<input type="submit" class="mui-btn mui-btn--raised mui-btn--primary" name="upload-net" value="Upload">
					</form> 
				</div>
				<div class="mui-panel mui--bg-color-grey-50">
					Download Configuration Files:
					<form action="" method="POST" enctype="multipart/form-data">
					<input name="SaveFileNet" type="submit" class="mui-btn mui-btn--raised mui-btn--primary" value="Download">
					</form>
				</div>
			</div>
		</div>
		<div class="mui-divider"></div>
		<div class="mui-row">
			<div class="mui-col-md-6">
				<legend>Wireless Scan</legend>
				<div class="mui-panel mui--bg-color-grey-50">
					<?php
						if (isset($_POST['survey'])){
							$A=file_get_contents('/tmp/tbv3/www/sitesurvey.tmp');
							echo nl2br($A);
						}
					?>
					<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
						<input type="submit" name="survey" value="Scan" class="mui-btn mui-btn--raised mui-btn--primary">     
					</form> 
				</div>
			</div>
			<div class="mui-col-md-6">
				<legend>Wireless Client Config</legend>
				<div class="mui-panel mui--bg-color-grey-50">
					<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
						<div class="mui-textfield mui-textfield--float-label">
							<input type="text" name="ssid" value="<?php echo $ssid; ?>">
							<label>ESSID</label>
						</div>
						<div class="mui-textfield mui-textfield--float-label">
							<input type="text" name="key" value="<?php echo $key; ?>">
							<label>KEY</label>
						</div>
						<div class="mui-select">
							<select name="encrypt">
								<option value="<?php echo $encrypt; ?>"><?php echo $encrypt; ?></option>
								<option value="open">open</option>
								<option value="wep">wep</option>
								<option value="wpa">wpa</option>
							</select>
							<label>Encryption</label>
						</div>
						<input type="submit" name="wificon" value="Submit" class="mui-btn mui-btn--small mui-btn--raised mui--bg-color-green-A400">     
					</form> 
				</div>
			</div>
		</div>
		<div class="mui-divider"></div>
		<div class="mui-row">
			<div class="mui-col-md-12">
				<legend>DNS</legend>
			</div>
			<div class="mui-col-md-6">
				<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
					<textarea class="textarealine" rows="15" name="dns-file"><?php Read_DNS(); ?></textarea>
					<div class="mui--text-center" style="margin:-20px 0 16px ;">
						<input type="submit" class="mui-btn mui-btn--small mui-btn--raised mui--bg-color-green-A400" name="update-dns" value="Update">
						<input type="submit" class="mui-btn mui-btn--small mui-btn--raised mui--bg-color-yellow-300" name="reload-dns" value="Reload">
						<input type="submit" class="mui-btn mui-btn--small mui-btn--raised mui-btn--primary" name="default-dns" value="Default">
					</div>
				</form>
			</div>
			<div class="mui-col-md-6">
				<div class="mui--clearfix"></div><br />
				<div class="mui-panel mui--bg-color-grey-50">
					<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
						
						<div class="mui-radio">
							Persistent DNS:
							<label>
								<input type="radio" name="locked" <?php if ($locked == "1")echo "checked";?> value="1">Locked
							</label>
							<label>
								<input type="radio" name="locked" <?php if ($locked == "0")echo "checked";?> value="0">Unlocked
							</label>
						</div>
						<input type="submit" name="persist" class="mui-btn mui-btn--small mui-btn--raised mui--bg-color-green-A400" value="Submit">
					</form>
				</div>
				<div class="mui-panel mui--bg-color-grey-50">
					Upload Configuration Files:
					<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST" enctype="multipart/form-data">
					<input type="file" name="uplod-dns">
					<input type="submit" class="mui-btn mui-btn--raised mui-btn--primary" name="upload-dns" value="Upload">
					</form> 
				</div>
				<div class="mui-panel mui--bg-color-grey-50">
					Download Configuration Files:
					<form action="" method="POST" enctype="multipart/form-data">
						<input name="SaveFileDNS" type="submit" class="mui-btn mui-btn--raised mui-btn--primary" value="Download">
					</form>
				</div>
			</div>
		</div>

	<!---	<?php
		if (isset($_POST['wificon'])){
			if(empty($_POST['ssid'])==false){
				echo "ESSID=".$_POST['encrypt'];echo "<br/>"; }
			if(empty($_POST['key'])==false){
				echo "KEY=".$_POST['key'];echo "<br/>"; }
			if(empty($_POST['encrypt'])==false){
				echo "ENCRYPT=".$_POST['encrypt'];echo "<br/>";}
		}
	?> --->
	
	</div>
</div>
<?php include 'footer.php'; ?>
