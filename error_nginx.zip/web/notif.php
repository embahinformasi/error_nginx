<?php
	$page = $_SERVER['PHP_SELF'];
	$sec = "6000";
	$title = "Notification Status";
	$stat_gpio = exec('tail /tmp/tbv3/notif_gpio');
	$stat_profile = exec('tail /tmp/tbv3/notif_profile');
	
	if (isset($_POST['btrestart'])){exec('sudo /opt/tbexec/restart /opt/tbexec/tbnotifierd');}
?>
<?php include 'head-nav.php'; ?>
<div id="content-wrapper">
	<div class="mui--appbar-height"></div>
	<div class="mui-container-fluid" id="content">
	<div id="Reload">
		<div class="mui-row">
			<div class="mui-col-md-12">
				<h1>Alarm Notification Status</h1>
				<div class="mui--text-center">
				<?php
					if (file_exists('/tmp/tbv3/.tbnotifierd')==TRUE){
						echo "<button class='mui-btn mui-btn--raised mui--bg-color-green-A400 sys-lbl'>Service Notification is running</button>";
					}else{
						echo "<button class='mui-btn mui-btn--raised mui-btn--danger sys-lbl'>Service Notification is stopped</button>";
					}
					if ($stat_gpio == 'Success'){
						echo "<button class='mui-btn mui-btn--raised mui--bg-color-green-A400 sys-lbl'>Notif GPIO Success</button>";
					}else{
						echo "<button class='mui-btn mui-btn--raised mui-btn--danger sys-lbl'>Notif GPIO Failed</button>";
					}
					if ($stat_profile == 'Success'){
						echo "<button class='mui-btn mui-btn--raised mui--bg-color-green-A400 sys-lbl'>Notif GPIO Success</button>";
					}else{
						echo "<button class='mui-btn mui-btn--raised mui-btn--danger sys-lbl'>Notif GPIO Failed</button>";
					}
				?>
				</div>
				<form method="post">
					<button name="btrestart" class="mui-btn mui-btn--raised mui-btn--primary mui--pull-right">Restart</button>
				</form>
			</div>
			<div class="mui-col-md-12">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend>Notification activity log</legend>
				<?php
					$handle = popen('tail /var/log/tbv3/tbnotifierd.log 2>&1', 'r');
					$read = fread($handle, 2048);
					//echo nl2br($read);
					echo str_replace( array("\n","Success","Failed"), 
						array('<span class="mui--pull-left"><strong>> &nbsp;</strong></span><br />', '<span class="mui--color-light-green-A700 mui--text-subhead">Success</span>','<span class="mui--text-danger">Failed</span>'),$read );
					pclose($handle);
				?>
				</div>
			</div>
			<div class="mui-col-md-12">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend>Event Alarm</legend>
				<?php
					$handle = popen('tail /var/log/tbv3/tbnotifierd.alarm.log 2>&1', 'r');
					$read = fread($handle, 2048);
					//echo nl2br($read);
					echo str_replace( "\n", '<span class="mui--pull-left"><strong>> &nbsp;</strong></span><br />', $read );
					pclose($handle);
				?>
				</div>
			</div>
			<div class="mui-col-md-12">
				<div class="mui-panel mui--bg-color-grey-50">
				Note: If you don't see anything, but all the services is up and running, don't panic!<br/>
				the log's just been logratated, you will see the activity again if any event occurs.
				</div>
			</div>
		</div>
	</div>
	</div>
</div>
<script>
/**
 * Refresh content Home dan status
 **/
var current_url = document.location;
function updateContent() {
		$("#content").load("<?echo "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";?> #Reload"); 
}
setInterval(updateContent, 15000); // 15 detik | 1000 = 1 dtk
</script>
<?php include 'footer.php'; ?>
