<?php
$title = "OpenVPN Config";

	if(isset($_FILES['uplod'])){
		$errors= array();
		$file_name = $_FILES['uplod']['name'];
		$file_size =$_FILES['uplod']['size'];
		$file_tmp =$_FILES['uplod']['tmp_name'];
		if($file_size > 2097152) $errors[]='Limit File Size 2MB exceeded!';
		if(empty($errors)==true){
			exec('[[ -d /tmp/www ]] || { sudo mkdir -p /tmp/www;sudo chmod 0777 /tmp/www; }');
      $target_dir = "/tmp/www/";
      $target_file = $target_dir . basename($_FILES['uplod']['name']);
      move_uploaded_file($_FILES['uplod']['tmp_name'], $target_file);
			exec ("sudo /opt/script/setcompvn $target_file > $target_dir/setcompvn.out 2>&1");
		} 
	} else if (isset($_POST['cleanvpn'])){
    exec('sudo /opt/script/cleanvpn');
  } else if (isset($_POST['btrestart'])){exec('sudo /etc/init.d/openvpn restart');}
    
	define("FILE_NAME", "/etc/openvpn/client.conf");

	function Read() {
		echo @file_get_contents(FILE_NAME);
	}
  function Write(){
		$data = $_POST["textfile"];
		@file_put_contents(FILE_NAME, $data);
   }

  if ($_POST["update-net"]) {
		exec ('sudo chmod 0777 /etc/openvpn/client.conf');
		Write();
	}
?>
     
<?php include 'head-nav.php'; ?>
<div id="content-wrapper">
	<div class="mui--appbar-height"></div>
	<div class="mui-container-fluid">
		<div class="mui-row">
			<div class="mui-col-md-12">
				<legend>OpenVPN Setup</legend>
			</div>
			<div class="mui-col-md-6">
				<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
				<textarea class="textarealine" rows="15" name="textfile"><?php Read(); ?></textarea>
				<div class="mui--text-center" style="margin:-20px 0 16px ;">
					<input type="submit" class="mui-btn mui-btn--small mui-btn--raised mui--bg-color-green-A400" name="update-net" value="Update">
					<input type="submit" class="mui-btn mui-btn--small mui-btn--raised mui-btn--primary" name="default-net" value="Default">
				</div>
				</form>
			</div>
			<div class="mui-col-md-6">
				<div class="row">
					<div class="mui-panel mui--bg-color-grey-50">
						<div class="mui-col-md-6">
							<legend>VPN Stat</legend>
							<form method="post">
								<button name="btrestart" class="mui-btn mui-btn--small mui-btn--raised mui-btn--primary">Restart</button>
							</form>
							<?php
								exec("pidof openvpn", $pids);
								if(empty($pids)) echo "Warning!, openvpn is stopped";
								else echo "Openvpn is up and running";
							?>
						</div>
						<div class="mui-col-md-6">
							<legend>Upload OpenVPN Files</legend>
							Support individual or compressed openvpn keys & config files in tar.gz,tar.bz2 or zip.
							<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST" enctype="multipart/form-data">
								<input type="file" name="uplod">
								<input type="submit" value="Upload" class="mui-btn mui-btn--small mui-btn--raised mui-btn--primary">
							</form>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="mui-panel mui--bg-color-grey-50">
						<legend>OpenVPN folder content:</legend>
						<?php
							$handle = popen('ls -l /etc/openvpn 2>&1', 'r');
							$read = fread($handle, 2048);
							echo nl2br($read);
							pclose($handle);
							echo "<br/>";
						?>

						<form method="post">
							<input Name="cleanvpn" type="submit" value="CleanVPN" onclick="return confirm('Are you sure?')" class="mui-btn mui-btn--small mui-btn--raised mui-btn--danger">
							Delete all VPN config files
						</form>
					</div>
				</div>
			</div>
		</div>

  <?php
    if ($_POST["update"]) echo 'Config Updated';
    else if ($_POST["reload"]) echo 'Config Reloaded';
		else if (isset($_FILES['uplod'])){
			if(empty($errors)==true) {
				echo 'Processing compressed openvpn config:<br/>';
				$MSG=file_get_contents("$target_dir/setcompvn.out");
				echo nl2br($MSG);
			}
			else print_r($errors);
		}
	?>
	</div>
</div>
<?php include 'footer.php'; ?>
