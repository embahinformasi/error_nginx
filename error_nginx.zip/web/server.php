<?php 
require_once("include/config.php");
require_once("include/PDOAccess.class.php");

$server_message = "";
if($_POST['CheckPort']){
	$ip = $_REQUEST['ip_test'];
	$port = $_REQUEST['port_test'];
	
	if(!($sock = socket_create(AF_INET, SOCK_STREAM, 0)))
	{
		$errorcode = socket_last_error();
		$errormsg = socket_strerror($errorcode);
		 
		$server_message = "Couldn't create socket: [$errorcode] $errormsg \n";
	}
	 
	$server_message =  "Socket created, ";	
	
	if(!socket_connect($sock , $ip , $port))
	{
		$errorcode = socket_last_error();
		$errormsg = socket_strerror($errorcode);
		 
		$server_message =  "Could not connect: [$errorcode] $errormsg \n";
	}
	else {
		$server_message = "IP $ip Port $port Connection established \n";		 
	}
	socket_close($sock);	
}
elseif($_POST['update_config_wp']) {
	$db_provider	= $_REQUEST["db_provider"];	
	$db_host			= $_REQUEST["db_host"];
	$db_port			= $_REQUEST["db_port"];
	$db_user			= $_REQUEST["db_user"];
	$db_pass			= $_REQUEST["db_pass"];
	$db_name			= $_REQUEST["db_name"];
	$db_sql_dump	= $_REQUEST["db_sql_dump"];
	$db_sql_desc	= $_REQUEST["db_sql_desc"];

	$db = new PDOAccess(G_DB_HOST, G_DB_USER, G_DB_PASS, G_DB_NAME, G_DB_PORT);
	$dsn = $db->GetDSN();
	$db->OpenDb($dsn);		

	$output = array();

	
	$sql = "select count(*) as jml_data, db_type_client, db_host_client, db_user_client, 
						db_pass_client, db_name_client, db_port_client, db_sql_dump  
					from config";
	$db->query($sql);	
	$data_config = $db->single();
	$cnt_data = $data_config["jml_data"];


	$sql = "";	
	if($cnt_data > 0) 
		$sql = "update config set db_type_client=:db_type, db_host_client=:db_host, db_user_client=:db_user,	
							db_pass_client=:db_pass, db_name_client=:db_name, db_port_client=:db_port, 
							db_sql_dump=:db_sql_dump, db_sql_desc=:db_sql_desc";
	else 
		$sql = "insert into config(db_type_client, db_host_client, db_user_client, 
							db_pass_client, db_name_client, db_port_client, db_sql_dump, db_sql_desc) 
						values(:db_type,:db_host,:db_user,:db_pass,:db_name,:db_port, 
									 :db_sql_dump, :db_sql_desc)";
	//echo $sql."\n $db_sql_desc";
	$db->query($sql);
	$db->bind(':db_type', "$db_provider");	
	$db->bind(':db_host', "$db_host");	
	$db->bind(':db_user', "$db_user");	
	$db->bind(':db_pass', "$db_pass");	
	$db->bind(':db_name', "$db_name");	
	$db->bind(':db_port', "$db_port");	
	$db->bind(':db_sql_dump', "$db_sql_dump");	
	$db->bind(':db_sql_desc', "$db_sql_desc");	
	$query_status = $db->execute();			

	if(!$query_status)
		$server_message = "Gagal mengupdate data !!!";
	else
		$server_message = "Data telah diupdate !!!";

	echo json_encode($output);
	$db->CloseDb();			
}
elseif($_POST['check_config_wp']) {
	$db_support = array("1", "2", "4", "5", "10");
	$output = array();		

	$db = new PDOAccess(G_DB_HOST, G_DB_USER, G_DB_PASS, G_DB_NAME, G_DB_PORT, 0);
	$dsn = $db->GetDSN();

	$db->OpenDb($dsn);	

	$sql = "select count(*) as jml_data, db_type_client, db_host_client, db_user_client, 
						db_pass_client, db_name_client, db_port_client, db_sql_dump  
					from config";
	
	$db->query($sql);	
	$config = $db->single();
	$cnt_data = $config["jml_data"];

	if($cnt_data > 0) {
		$db_host 			= $config["db_host_client"];
		$db_port 			= $config["db_port_client"];
		$db_user 			= $config["db_user_client"];
		$db_pass 			= $config["db_pass_client"];
		$db_name		 	= $config["db_name_client"];	
		$db_provider	= $config["db_type_client"];	 

		if(!in_array($config["db_type_client"], $db_support)) {
			$status = true;
			$message = "";

			exec('java -jar /var/web/tb_exec/ConectionTestPhp.jar', $message);	
			$server_message = $message;
		}
		else {
			$db_client = new PDOAccess($config["db_host_client"], $config["db_user_client"], $config["db_pass_client"], 
											$config["db_name_client"], $config["db_port_client"], $config["db_type_client"]);
			$dsn_client = $db_client->GetDSN();									

			try {
				$db_client->OpenDb($dsn_client);	
				$server_message = "Koneksi berhasil !!!";
			}
			catch(Exception $e) {

				$status = false;
				$message = $e->getMessage();
				$db_client->CloseDb();
				$server_message = $message;
			}						
		}
	}
	else {
		$server_message = "Config belum diset !!!";
	}
	$db->CloseDb();	
}
elseif($_POST['update_config_server']) {
		$dev_id		= $_REQUEST["dev_id"];	
		$db_host	= $_REQUEST["db_host_server"];
		$db_port	= $_REQUEST["db_port_server"];
		$db_user	= $_REQUEST["db_user_server"];
		$db_pass	= $_REQUEST["db_pass_server"];
		$db_name	= $_REQUEST["db_name_server"];
		$timezone	= $_REQUEST["timezone"];

		$db = new PDOAccess(G_DB_HOST, G_DB_USER, G_DB_PASS, G_DB_NAME, G_DB_PORT);
		$dsn = $db->GetDSN();
		$db->OpenDb($dsn);		

		$output = array();

		
		$sql = "select count(*) as jml_data, db_host_server, db_user_server, 
							db_pass_server, db_name_server, db_port_server
						from config";
		$db->query($sql);	
		$data_config = $db->single();
		$cnt_data = $data_config["jml_data"];


		$sql = "";	
		if($cnt_data > 0) 
			$sql = "update config set db_host_server=:db_host, db_user_server=:db_user,	
								db_pass_server=:db_pass, db_name_server=:db_name, db_port_server=:db_port, 
								dev_id=:dev_id, timezone=:timezone";
		else 
			$sql = "insert into config(db_host_server, db_user_server, 
								db_pass_server, db_name_server, db_port_server, dev_id, timezone) 
							values(:db_host,:db_user,:db_pass,:db_name,:db_port, :dev_id, :timezone)";
		//echo $sql."\n $db_sql_desc";
		$db->query($sql);
		$db->bind(':db_host', "$db_host");	
		$db->bind(':db_user', "$db_user");	
		$db->bind(':db_pass', "$db_pass");	
		$db->bind(':db_name', "$db_name");	
		$db->bind(':db_port', "$db_port");	
		$db->bind(':db_port', "$db_port");	
		$db->bind(':dev_id', "$dev_id");	
		$db->bind(':timezone', "$timezone");	
		$query_status = $db->execute();			

		if(!$query_status)
			$server_message = "Gagal mengupdate data !!!";
		else
			$server_message = "Data telah diupdate !!!";

		$db->CloseDb();			
}
elseif($_POST['check_config_server']) {
		$output = array();		

		$db = new PDOAccess(G_DB_HOST, G_DB_USER, G_DB_PASS, G_DB_NAME, G_DB_PORT, 0);
		$dsn = $db->GetDSN();

		$db->OpenDb($dsn);	

		$sql = "select count(*) as jml_data, db_host_server, db_user_server, 
							db_pass_server, db_name_server, db_port_server 
						from config";
		
		$db->query($sql);	
		$config = $db->single();
		$cnt_data = $config["jml_data"];
		$db->CloseDb();
		if($cnt_data > 0) {
			$db_host 			= $config["db_host_server"];
			$db_port 			= $config["db_port_server"];
			$db_user 			= $config["db_user_server"];
			$db_pass 			= $config["db_pass_server"];
			$db_name		 	= $config["db_name_server"];	 

			$db_server = new PDOAccess($config["db_host_server"], $config["db_user_server"], $config["db_pass_server"], 
											$config["db_name_server"], $config["db_port_server"]);
			$dsn_server = $db_server->GetDSN();									

			try {
				$db_server->OpenDb($dsn_server);	
				$server_message = "Koneksi berhasil !!!";
				$db_server->CloseDb();
			}
			catch(Exception $e) {

				$status = false;
				$message = $e->getMessage();
				$db_server->CloseDb();
				$server_message = $message;
			
			}		
		}
		else {
			$server_message = "Config belum diset !!!";
		}
		echo json_encode($output);
}

$selected1 = "";
$selected2 = "";
$selected3 = "";
$selected4 = "";
$selected5 = "";
$selected6 = "";
$selected7 = "";
$selected8 = "";
$selected9 = "";
$selected10 = "";
$selected11 = "";

$db_host = "";
$db_port = "";
$db_user = "";
$db_pass = "";
$db_name = "";
$db_provider = "";
$db_sql_desc = "";
$db_sql_dump = "";

$db_host_server = "";
$db_port_server = "";
$db_user_server = "";
$db_pass_server = "";
$db_name_server = "";
$dev_id					= "";
$timezone				= "";

$db = new PDOAccess(G_DB_HOST, G_DB_USER, G_DB_PASS, G_DB_NAME, G_DB_PORT);
$dsn = $db->GetDSN();
$db->OpenDb($dsn);	

$sql = "select count(*) as jml_data, db_type_client, db_host_client, db_user_client, 
					db_pass_client, db_name_client, db_port_client, db_sql_dump, db_sql_desc,
 					db_host_server, db_user_server, 
					db_pass_server, db_name_server, db_port_server, dev_id, timezone  
				from config";
$db->query($sql);	
$data_config = $db->single();
$cnt_data = $data_config["jml_data"];

if($cnt_data > 0) {
	$db_host 			= $data_config["db_host_client"];
	$db_port 			= $data_config["db_port_client"];
	$db_user 			= $data_config["db_user_client"];
	$db_pass 			= $data_config["db_pass_client"];
	$db_name		 	= $data_config["db_name_client"];	
	$db_provider	= $data_config["db_type_client"];	 
	$db_sql_desc 	= $data_config["db_sql_desc"];
	$db_sql_dump 	= $data_config["db_sql_dump"];
	

	$selected1 = ($db_provider == "1") ? "selected='selected'" : "";
	$selected2 = ($db_provider == "2") ? "selected='selected'" : "";
	$selected3 = ($db_provider == "3") ? "selected='selected'" : "";
	$selected4 = ($db_provider == "4") ? "selected='selected'" : "";
	$selected5 = ($db_provider == "5") ? "selected='selected'" : "";
	$selected6 = ($db_provider == "6") ? "selected='selected'" : "";
	$selected7 = ($db_provider == "7") ? "selected='selected'" : "";
	$selected8 = ($db_provider == "8") ? "selected='selected'" : "";
	$selected9 = ($db_provider == "9") ? "selected='selected'" : "";
	$selected10 = ($db_provider == "10") ? "selected='selected'" : "";
	$selected11 = ($db_provider == "11") ? "selected='selected'" : "";


	$db_host_server = $data_config["db_host_server"];
	$db_port_server = $data_config["db_port_server"];
	$db_user_server = $data_config["db_user_server"];
	$db_pass_server = $data_config["db_pass_server"];
	$db_name_server	= $data_config["db_name_server"];	
	$dev_id					= $data_config["dev_id"];	
	$timezone				= $data_config["timezone"];	

	$selected_timezone1 = ($timezone == "1") ? "selected='selected'" : "";
	$selected_timezone2 = ($timezone == "2") ? "selected='selected'" : "";
	$selected_timezone3 = ($timezone == "3") ? "selected='selected'" : "";
}
$db->CloseDb();

echo "<h3>";
echo $server_message;
echo "</h3>";
?>

<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" id="form_server_cek_port" name="form_server_cek_port">
<legend>Test Port</legend>
<div class="row">
	<div class="mui-panel mui--bg-color-grey-50">	
		<div class="mui-col-md-10">
			<div class="mui-textfield mui-textfield--float-label">
				<input type="text" name="ip" id="ip" value="">
				<label>Server URL</label>
			</div>
		</div>
		<div class="mui-col-md-2">	
		</div>
		<div class="mui-col-md-10">
			<div class="mui-textfield mui-textfield--float-label">
				<input type="text" name="port" id="port" value="">
				<label>Port</label>
			</div>
		</div>
		<div class="mui-col-md-2">	
		</div>		
		<div class="mui-col-md-6">
		</div>
		<div class="mui-col-md-6">
			<input type="submit" class="mui-btn mui-btn--raised mui--bg-color-green-A400" name="CheckPort" value="&#128190; Cek Port">
		</div>
	</div>
</div>		
</form>
<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" id="form_server_config" name="form_server_config">
<legend>Konfigurasi Database WP</legend>
<div class="row">
	<div class="mui-panel mui--bg-color-grey-50">	
		<div class="mui-col-md-10">
			<div class="mui-textfield mui-textfield--float-label">
				<select id="db_provider" name="db_provider">
					<option value="0">Pilih Provider</option>
					<option value="1" <?=$selected1?>>1  - Mysql/Maria DB</option>
					<option value="2" <?=$selected2?>>2  - Sql Server</option>
					<option value="3" <?=$selected3?>>3  - Oracle (Java Application)</option>
					<option value="4" <?=$selected4?>>4  - Postgresql</option>
					<option value="5" <?=$selected5?>>5  - Firebird</option>
					<option value="6" <?=$selected6?>>6  - ODBC</option>
					<option value="7" <?=$selected7?>>7  - Sqlite</option>
					<option value="8" <?=$selected8?>>8  - DB2 (Java Application)</option>
					<option value="9" <?=$selected9?>>9  - Progress DB/OpenEdge (Java Application)</option>
					<option value="10" <?=$selected10?>>10 - Sybase (Java Application)</option>
					<option value="11" <?=$selected11?>>11 - Apache Derby (Java Application)</option>
				</select>
				<label>Database Provider</label>
			</div>
		</div>
		<div class="mui-col-md-2">	
		</div>
		
		<div class="mui-col-md-10">
			<div class="mui-textfield mui-textfield--float-label">
				<input type="text" name="db_host" id="db_host" value="<?=$db_host?>">
				<label>Database Host</label>
			</div>
		</div>
		<div class="mui-col-md-2">	
		</div>
		
		<div class="mui-col-md-10">
			<div class="mui-textfield mui-textfield--float-label">
				<input type="text" name="db_port" id="db_port" value="<?=$db_port?>">
				<label>Database Port</label>
			</div>
		</div>
		<div class="mui-col-md-2">	
		</div>
		
		<div class="mui-col-md-10">
			<div class="mui-textfield mui-textfield--float-label">
				<input type="text" name="db_user" id="db_user" value="<?=$db_user?>">
				<label>Database User</label>
			</div>
		</div>
		<div class="mui-col-md-2">	
		</div>
		
		<div class="mui-col-md-10">
			<div class="mui-textfield mui-textfield--float-label">
				<input type="text" name="db_pass" id="db_pass" value="<?=$db_pass?>">
				<label>Database Password</label>
			</div>
		</div>
		<div class="mui-col-md-2">	
		</div>
		
		<div class="mui-col-md-10">
			<div class="mui-textfield mui-textfield--float-label">
				<input type="text" name="db_name" id="db_name" value="<?=$db_name?>">
				<label>Database Name</label>
			</div>
		</div>
		<div class="mui-col-md-2">	
		</div>
		
		<div class="mui-col-md-10">
			<div class="mui-textfield mui-textfield--float-label">
				<textarea type="textare" name="db_sql_dump" id="db_sql_dump"><?=$db_sql_dump?></textarea>
				<label>SQL Dump</label>
			</div>
		</div>
		<div class="mui-col-md-2">	
		</div>
		
		<div class="mui-col-md-10">
			<div class="mui-textfield mui-textfield--float-label">
				<textarea type="textare" name="db_sql_desc" id="db_sql_desc"><?=$db_sql_dump?></textarea>
				<label>SQL Desc</label>
			</div>
		</div>
		<div class="mui-col-md-2">	
		</div>															
		<div class="mui-col-md-6">
		</div>
		<div class="mui-col-md-6">
			<input type="submit" class="mui-btn mui-btn--raised mui--bg-color-green-A400" id="update_config_wp" name="update_config_wp" value="&#128190; Update">
			<input type="submit" class="mui-btn mui-btn--raised mui--bg-color-green-A400" id="check_config_wp" name="check_config_wp" value="&#128190; Cek Koneksi">
		</div>	
	
	</div>
</div>	
</form>

<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post">
<legend>Konfigurasi Database Server</legend>
<div class="row">
	<div class="mui-panel mui--bg-color-grey-50">	
	
		<div class="mui-col-md-10">
			<div class="mui-textfield mui-textfield--float-label">
				<select id="timezone" name="timezone">
					<option value="1" <?=$selected_timezone1?>>1  - Asia/Jakarta</option>
					<option value="2" <?=$selected_timezone2?>>2  - Asia/Makassar</option>
					<option value="3" <?=$selected_timezone3?>>3  - Asia/Jayapura</option>
				</select>
				<label>Timezone</label>
			</div>
		</div>
		<div class="mui-col-md-2">	
		</div>
		
		<div class="mui-col-md-10">
			<div class="mui-textfield mui-textfield--float-label">
				<input type="text" name="dev_id" id="dev_id" value="<?=$dev_id?>">
				<label>Device ID</label>
			</div>
		</div>
		<div class="mui-col-md-2">	
		</div>
		
		<div class="mui-col-md-10">
			<div class="mui-textfield mui-textfield--float-label">
				<input type="text" name="db_host_server" id="db_host_server" value="<?=$db_host_server?>">
				<label>Database Host Server</label>
			</div>
		</div>
		<div class="mui-col-md-2">	
		</div>
		
		<div class="mui-col-md-10">
			<div class="mui-textfield mui-textfield--float-label">
				<input type="text" name="db_port_server" id="db_port_server" value="<?=$db_port_server?>">
				<label>Database Port Server</label>
			</div>
		</div>
		<div class="mui-col-md-2">	
		</div>
		
		<div class="mui-col-md-10">
			<div class="mui-textfield mui-textfield--float-label">
				<input type="text" name="db_user_server" id="db_user_server" value="<?=$db_user_server?>">
				<label>Database User</label>
			</div>
		</div>
		<div class="mui-col-md-2">	
		</div>
		
		<div class="mui-col-md-10">
			<div class="mui-textfield mui-textfield--float-label">
				<input type="text" name="db_pass_server" id="db_pass_server" value="<?=$db_pass_server?>">
				<label>Database Password</label>
			</div>
		</div>
		<div class="mui-col-md-2">	
		</div>							
	
		<div class="mui-col-md-10">
			<div class="mui-textfield mui-textfield--float-label">
				<input type="text" name="db_name_server" id="db_name_server" value="<?=$db_name_server?>">
				<label>Database Name</label>
			</div>
		</div>
		<div class="mui-col-md-2">	
		</div>		
	
		<div class="mui-col-md-6">
		</div>	
		<div class="mui-col-md-6">
			<input type="submit" class="mui-btn mui-btn--raised mui--bg-color-green-A400" id="update_config_server" name="update_config_server" value="&#128190; Update">
			<input type="submit" class="mui-btn mui-btn--raised mui--bg-color-green-A400" id="check_config_server" name="check_config_server" value="&#128190; Cek Koneksi">
		</div>	
	</div>
</div>	
</form>		


<?php 
/*
												
		
			*/
?>
