<!DOCTYPE html>
<?php
	$page = $_SERVER['PHP_SELF'];$sec = "0";
?>
<html>
  <head>
	<title>TappingBoxV3</title>
  <meta http-equiv="refresh" content="<?php echo $sec?>;URL=config.php">
	</head>
  <title>TappingBoxV3</title>
  <body>
  <body bgcolor="#00FFFF">
  <font face="monospace" color="#000000">
  <A href=home.php>Home</A>
  <A href=setup.php>Setup</A>
  <A href=status.php>Status</A>
  <A href=system.php>System</A>
  <br/>
  <A href=config.php>Config</A>
  <A href=wvdial.php>Wvdial</A>
  <A href=gammu.php>Gammu</A>
  <A href=netconf.php>Network</A>
  <br/>
	</font>
	</body>
</html>
