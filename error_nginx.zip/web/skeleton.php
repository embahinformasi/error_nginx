<!DOCTYPE html>
<?php
	//$page = $_SERVER['PHP_SELF'];$sec = "3";
?>
<html>
  <head>
	<title>TappingBoxV3</title>
  <!---<meta http-equiv="refresh" content="<?php echo $sec?>;URL=home.php">--->
	</head>
  <title>TappingBoxV3</title>
  <body>
  <body bgcolor="#00FFFF">
  <font face="monospace" color="#000000">
  <A href=home.php>Home</A>

	</font>
	</body>
</html>
