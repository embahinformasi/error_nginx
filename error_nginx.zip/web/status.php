<!DOCTYPE html>
<?php
	$page = $_SERVER['PHP_SELF'];$sec = "0";
?>
<html>
  <head>
	<title>TappingBoxV3</title>
  <meta http-equiv="refresh" content="<?php echo $sec?>;URL=tabsysmon.php">
	</head>
  <title>TappingBoxV3</title>
  <body>
  <body bgcolor="#00FFFF">
  <font face="monospace" color="#000000">
  <A href=home.php>Home</A>
  <A href=setup.php>Setup</A>
  <A href=status.php>Status</A>
  <A href=system.php>System</A>
	<br/>
  <A href=tabsysmon.php>Sysmon</A>
  <A href=notif.php>Notifier</A>
  <A href=capstat.php>Printer</A>
  <A href=modem.php>Modem</A>
  <A href=update.php>Update</A>
  <A href=network.php>Network</A>
	</font>
	</body>
</html>
