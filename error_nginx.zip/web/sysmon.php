<!DOCTYPE html>
<?php
$page = $_SERVER['PHP_SELF'];
$sec = "5";
if (isset($_POST['btrestart1'])){exec('sudo /opt/tbexec/restart /opt/tbexec/tbsysmond');}
if (isset($_POST['btrestart2'])){exec('sudo /opt/tbexec/restart /opt/tbexec/tbmongpiod');}
?>
<html>
	<head>
	<meta http-equiv="refresh" content="<?php echo $sec?>;URL='<?php echo $page?>'">
	</head>
	<title>TappingBoxV3</title>
	<body>
 	<body bgcolor="#00FFFF">
	<font face="monospace" color="#000000">
  <A href=home.php>Home</A>
  <A href=setup.php>Setup</A>
  <A href=status.php>Status</A>
  <A href=system.php>System</A>
	<br/>
  <A href=sysmon.php>Sysmon</A>
  <A href=alarm.php>Alarm</A>
  <A href=notif.php>Notifier</A>
  <A href=capstat.php>Printer</A>
  <A href=modem.php>Modem</A>
  <A href=update.php>Update</A>
  <A href=network.php>Network</A>
	
	<h1>System Status</h1>

    <form method="post"><p> <button name="btrestart1">Restart</button>
    <?php
    if (file_exists('/tmp/tbv3/.tbsysmond')==TRUE) echo "Service system monitor is up";
      else echo "Warning: Service system monitor is stopped!";
    echo nl2br("\n");
    ?>
    </p></form>

    <form method="post"><p> <button name="btrestart2">Restart</button>
    <?php
    if (file_exists('/tmp/tbv3/.tbmongpiod')==TRUE) echo "Service gpio monitor is up";
      else echo "Warning: Service gpio monitor is stopped!";
    echo nl2br("\n");
    ?>
    </p></form>

  <h2>System Load</h2>
	CPU Load=<?php>$A=(file_get_contents('/tmp/tbv3/objmon/cpuload'));echo "$A%,"; ?>
  CPU Temperature=<?php>$A=(file_get_contents('/tmp/tbv3/objmon/cputemp'));echo "$A C,"; ?>
  Memory=<?php>$A=(file_get_contents('/tmp/tbv3/objmon/memusage'));echo "$A%,"; ?>
  Disk usage=<?php>$A=(file_get_contents('/tmp/tbv3/objmon/diskusage'));echo "$A%,"; ?>

  <h2>Power Supply</h2>
	Power Supply=<?php> $A=(file_get_contents('/tmp/tbv3/objmon/pwrplug')); 
		if($A == "1\n" ){ echo "Plugged,";} else { echo "Unplugged,";} ?>
	Battery Capacity=<?php> $A=(file_get_contents('/tmp/tbv3/objmon/battlvl'));echo "$A%,"; ?> 
	Charging=<?php> $A=(file_get_contents('/tmp/tbv3/objmon/charge')); 
		if($A == "1\n" ){ echo "Charging,";} else { echo "Discharging/Full";} ?>

	<h2>Hardware Detection</h2>
  Interface Serial=<?php>$A=(file_get_contents('/tmp/tbv3/objmon/intcap1'));echo "$A,"; ?>	
  Interface Lpt=<?php>$A=(file_get_contents('/tmp/tbv3/objmon/intcap2'));echo "$A,"; ?>	
  Interface USB=<?php>$A=(file_get_contents('/tmp/tbv3/objmon/intcap3'));echo "$A,"; ?> 	
  Lpt Converter=<?php>$A=(file_get_contents('/tmp/tbv3/objmon/lptatmega'));echo "$A,"; ?><br/>
  Interface Lan=<?php>$A=(file_get_contents('/tmp/tbv3/objmon/iflan'));echo "$A,"; ?> 	
  Interface Wifi=<?php>$A=(file_get_contents('/tmp/tbv3/objmon/ifwlan'));echo "$A,"; ?> 	
  Interface Modem=<?php>$A=(file_get_contents('/tmp/tbv3/objmon/ifmodem'));echo "$A,"; ?> 	


	<h2>Network Connection</h2>
	Modem=<?php> $A=(file_get_contents('/tmp/tbv3/objmon/conmodem'));
    if($A == "1\n" ){ echo "Connected,";} else { echo "Unconnected,";} ?>	
	Lan=<?php> $A=(file_get_contents('/tmp/tbv3/objmon/conlan'));
    if($A == "1\n" ){ echo "Connected,";} else { echo "Unconnected,";} ?>	
	Wifi=<?php> $A=(file_get_contents('/tmp/tbv3/objmon/conwlan'));
    if($A == "1\n" ){ echo "Connected,";} else { echo "Unconnected,";} ?>	
	VPN=<?php> $A=(file_get_contents('/tmp/tbv3/objmon/convpn'));
    if($A == "1\n" ){ echo "Connected,";} else { echo "Unconnected,";} ?>	

	<h2>GSM Info</h2>
  Signal Strength=<?php> $A=(file_get_contents('/tmp/tbv3/objmon/sigmodem'));echo "$A,"; ?><br/>	
  Billing Info=<?php> $A=(file_get_contents('/tmp/tbv3/objmon/billmodem'));echo "$A,"; ?><br/>	
  Quota Info=<?php> $A=(file_get_contents('/tmp/tbv3/objmon/quotamodem'));echo "$A,"; ?>	

  <h2>Temper Detection</h2>
  Serial DTR=<?php> $A=(file_get_contents('/tmp/tbv3/objmon/tser1'));echo "$A,";?>
  	Serial DSR=<?php> $A=(file_get_contents('/tmp/tbv3/objmon/tser2'));echo "$A,";?>
  LPT Select In=<?php> $A=(file_get_contents('/tmp/tbv3/objmon/tlpt1'));echo "$A,"; ?>
  	LPT Select Out=<?php> $A=(file_get_contents('/tmp/tbv3/objmon/tlpt2'));echo "$A,"; ?><br/>
  USB Power=<?php> $A=(file_get_contents('/tmp/tbv3/objmon/tusb'));echo "$A,"; ?>
  Vibration=<?php> $A=(file_get_contents('/tmp/tbv3/objmon/tvibra'));echo "$A,"; ?>
  Open Casing=<?php> $A=(file_get_contents('/tmp/tbv3/objmon/tcasing'));echo "$A,"; ?>
	
	</font>
	</body>
</html>
