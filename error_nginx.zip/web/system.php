<!DOCTYPE html>
<?php
	$page = $_SERVER['PHP_SELF'];$sec = "0";
?>
<html>
  <head>
	<title>TappingBoxV3</title>
  <meta http-equiv="refresh" content="<?php echo $sec?>;URL=admin.php">
	</head>
  <title>TappingBoxV3</title>
  <body>
  <body bgcolor="#00FFFF">
  <font face="monospace" color="#000000">
	<A href=home.php>Home</A>
  <A href=setup.php>Setup</A>
  <A href=status.php>Status</A>
  <A href=system.php>System</A>
	<br/>
  <A href=files/>Files</A>
  <A href=admin.php>Admin</A>
  <A href=about.php>About</A>

	</font>
	</body>
</html>
