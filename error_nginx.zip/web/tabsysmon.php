<?php
	$page = $_SERVER['PHP_SELF'];
	$sec = "5000";
	$title = "System Status";
	exec('[[ -d /tmp/tbv3/www ]] || { sudo mkdir -p /tmp/tbv3/www;sudo chmod 0777 /tmp/tbv3/www; } ');
	if (isset($_POST['btrestart'])){exec('sudo /opt/tbexec/tbgpiosysmond restart');}

	function showalarm($alarm){
		$val=file_get_contents("/tmp/tbv3/alarm/$alarm");
		if($val=="1\n"){
			exec("/opt/tbexec/getvalue /etc/tbv3/tbv3.conf string_alarm_rising $alarm > /tmp/tbv3/www/string_alarm.tmp");
			$val=file_get_contents("/tmp/tbv3/www/string_alarm.tmp");
		}else $val="-";
		return $val;
	}
?>

<?php include 'head-nav.php'; ?>
<div id="content-wrapper">
	<div class="mui--appbar-height"></div>
	<div class="mui-container-fluid" id="content">
	<div id="Reload">
		<div class="mui-row">
			<div class="mui-col-md-12">
				<h1>System Status</h1>
				<div class="mui--text-center">
				<?php
					if (file_exists('/tmp/tbv3/.tbsysmond')==TRUE)
						echo "<button class='mui-btn mui-btn--raised mui--bg-color-green-A400 sys-lbl'>Service system monitor is running</button>";
					else 
						echo "<button class='mui-btn mui-btn--raised mui-btn--danger sys-lbl'>Service system monitor is stopped</button>";
					
					if (file_exists('/tmp/tbv3/.tbmongpiod')==TRUE) 
						echo "<button class='mui-btn mui-btn--raised mui--bg-color-green-A400 sys-lbl'>Service GPIO is running</button>";
					else 
						echo "<button class='mui-btn mui-btn--raised mui-btn--danger sys-lbl'>Service gpio monitor is stopped!</button>";
					if (file_exists('/tmp/tbv3/.tbalarmd')==TRUE) 
						echo "<button class='mui-btn mui-btn--raised mui--bg-color-green-A400 sys-lbl'>Service alarm is running</button>";
					else 
						echo "<button class='mui-btn mui-btn--raised mui-btn--danger sys-lbl'>Service alarm is stopped!</button>";
					if (file_exists('/tmp/tbv3/.tbnotifierd')==TRUE)
						echo "<button class='mui-btn mui-btn--raised mui--bg-color-green-A400 sys-lbl'>Service notification is running</button>";
					else 
						echo "<button class='mui-btn mui-btn--raised mui-btn--danger sys-lbl'>Service notification is stopped</button>";
				?>
				</div>
				<form method="post">
					<button name="btrestart" class="mui-btn mui-btn--raised mui-btn--primary mui--pull-right">Restart</button></form>
			</div>
		</div>
		
		<div class="mui-row">
			<div class="mui-col-md-6">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend>System Load</legend>
					<table class="mui-table mui-table--bordered">
						<tr bgcolor="#dddddd">
							<th>Object</th>
							<th>Value</th>
							<th>Alarm</th>
						</tr>
						<tr>
							<td>CPU Load</td>
							<td><?php>$A=(file_get_contents('/tmp/tbv3/objmon/cpuload'));echo "$A%"; ?></td>
							<td><?php $val=showalarm("cpuload");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>CPU Temperature</td>
							<td><?php>$A=(file_get_contents('/tmp/tbv3/objmon/cputemp'));echo "$A C"; ?></td>
							<td><?php $val=showalarm("cputemp");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>Memory Usage</td>
							<td><?php>$A=(file_get_contents('/tmp/tbv3/objmon/memusage'));echo "$A%"; ?></td>
							<td><?php $val=showalarm("memusage");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>Disk Usage</td>
							<td><?php>$A=(file_get_contents('/tmp/tbv3/objmon/diskusage'));echo "$A%"; ?></td>
							<td><?php $val=showalarm("diskusage");echo "$val"; ?></td>
						</tr>
					</table>
				</div>
			</div>
			<div class="mui-col-md-6 mui--pull-left">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend style="width:auto; float:left;">Network Connection</legend>
					<legend style="width:auto;" class="mui--pull-right">
					<div class="mui-textfield" style="margin-bottom:0px;">
						<?php $alias = shell_exec("/sbin/ifconfig eth0:0 | grep 'inet addr' | cut -d: -f2 | awk '{ print $1}'");?>
						<input type="text" value="<?=$alias?>" disabled>
						<label>IP Alias</label>
					</div>
					</legend>
					<table class="mui-table mui-table--bordered">
						<tr bgcolor="#dddddd">
							<th>Object</th>
							<th>Value</th>
							<th>Address</th>
							<th>Alarm</th>
						</tr>
						<tr>
							<td>Modem</td>
							<td>
								<?php 
									$A=(file_get_contents('/tmp/tbv3/objmon/conmodem'));
									if($A == "1\n" ){ echo "Up";} else { echo "Down";} 
								?>
							</td>
							<td>
								<?php echo shell_exec("/sbin/ifconfig ppp0 | grep 'inet addr' | cut -d: -f2 | awk '{ print $1}'");?>
							</td>
							<td><?php $val=showalarm("conmodem");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>Lan</td>
							<td><?php 
								$A=(file_get_contents('/tmp/tbv3/objmon/conlan'));
								if($A == "1\n" ){ echo "Up";} else { echo "Down";} 
							?></td>
							<td>
								<?php echo shell_exec("/sbin/ifconfig eth0 | grep 'inet addr' | cut -d: -f2 | awk '{ print $1}'");?>
							</td>
							<td><?php $val=showalarm("conlan");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>Wifi</td>
							<td><?php 
								$A=(file_get_contents('/tmp/tbv3/objmon/conwlan'));
								if($A == "1\n" ){ echo "Up";} else { echo "Down";} 
							?></td>
							<td>
								<?php echo shell_exec("/sbin/ifconfig wlan0 | grep 'inet addr' | cut -d: -f2 | awk '{ print $1}'");?>
							</td>
							<td><?php $val=showalarm("conwlan");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>VPN</td>
							<td><?php> 
								$A=(file_get_contents('/tmp/tbv3/objmon/convpn'));
								if($A == "1\n" ){ echo "Up";} else { echo "Down";} 
							?></td>
							<td>
								<?php echo shell_exec("/sbin/ifconfig tun0 | grep 'inet addr' | cut -d: -f2 | awk '{ print $1}'");?>
							</td>
							<td><?php $val=showalarm("convpn");echo "$val"; ?></td>
						</tr>
						<tr>
							<th>NameServer</th>
							<? $nameservers = explode('nameserver ', file_get_contents('/etc/resolv.conf'));?>
							<td>
								<?
									echo implode("", $nameservers);
								?>
							</td>
							<th>
								Default Route
							</th>
							<td>
								<?php echo shell_exec("ip route show | grep 'default' | awk '{print $3}'");?>
							</td>
						</tr>
					</table>
				</div>
			</div>
			<div class="mui-col-md-6 mui--pull-left">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend>Power Supply</legend>
					<table class="mui-table mui-table--bordered">
						<tr bgcolor="#dddddd">
							<th>Object</th>
							<th>Value</th>
							<th>Alarm</th>
						</tr>
						<tr>
							<td>Power Supply</td>
							<td><?php
								$A=(file_get_contents('/tmp/tbv3/objmon/pwrplug'));
								if($A == "1\n" ){ $plug=1;echo "Plugged";} else { $plug=0;echo "Unplugged";} 
							?></td>
							<td><?php $val=showalarm("pwrplug");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>Battery Capacity</td>
							<td><?php
								$A=(file_get_contents('/tmp/tbv3/objmon/battlvl'));echo "$A %";
							?></td>
							<td><?php $val=showalarm("battlvl");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>Charging</td>
							<td><?php
								$A=(file_get_contents('/tmp/tbv3/objmon/charge'));
								if($A=="1\n") { echo "Charging";} else { 
									if($plug==1){ echo "Full"; } else {echo "Discharging";}
								}
							?></td>
							<td></td>
						</tr>
					</table>
				</div>
			</div>
			<div class="mui-col-md-6 mui--pull-left">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend>GSM Info</legend>
					<table class="mui-table mui-table--bordered">
						<tr bgcolor="#dddddd">
							<th>Object</th>
							<th>Value</th>
							<th>Alarm</th>
						</tr>
						<tr>
							<td>Signal Strength</td>
							<td><?php 
								$A=(file_get_contents('/tmp/tbv3/objmon/sigmodem'));echo "$A %"; 
							?></td>
							<td><?php $val=showalarm("sigmodem");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>Billing Info</td>
							<td><?php 
								$A=(file_get_contents('/tmp/tbv3/objmon/billmodem'));
								$A=str_replace("%20"," ",$A);
								echo "$A"; 
							?></td>
							<td><?php $val=showalarm("billmodem");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>Quota Info</td>
							<td><?php 
								$A=(file_get_contents('/tmp/tbv3/objmon/quotamodem'));
								$A=str_replace("%20"," ",$A);
								echo "$A";
							?></td>
							<td><?php $val=showalarm("quotamodem");echo "$val"; ?></td>
						</tr>
					</table>
				</div>
			</div>
			<div class="mui-col-md-6">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend>Hardware Detection</legend>
					<table class="mui-table mui-table--bordered">
						<tr bgcolor="#dddddd">
							<th>Object</th>
							<th>Value</th>
							<th>Alarm</th>
						</tr>
						<tr>
							<td>Interface Serial</td>
							<td><?php>$A=(file_get_contents('/tmp/tbv3/objmon/intcap1'));echo "$A"; ?></td>
							<td><?php $val=showalarm("intcap1");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>Interface Lpt</td>
							<td><?php>$A=(file_get_contents('/tmp/tbv3/objmon/intcap2'));echo "$A"; ?></td>
							<td><?php $val=showalarm("intcap2");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>Interface USB</td>
							<td><?php>$A=(file_get_contents('/tmp/tbv3/objmon/intcap3'));echo "$A"; ?></td>
							<td><?php $val=showalarm("intcap3");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>Lpt Converter</td>
							<td><?php>$A=(file_get_contents('/tmp/tbv3/objmon/lptatmega'));echo "$A"; ?></td>
							<td><?php $val=showalarm("lptatmega");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>Interface Lan</td>
							<td><?php>$A=(file_get_contents('/tmp/tbv3/objmon/iflan'));echo "$A"; ?></td>
							<td><?php $val=showalarm("iflan");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>Interface Wifi</td>
							<td><?php>$A=(file_get_contents('/tmp/tbv3/objmon/ifwlan'));echo "$A"; ?></td>
							<td><?php $val=showalarm("ifwlan");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>Interface Modem</td>
							<td><?php>$A=(file_get_contents('/tmp/tbv3/objmon/ifmodem'));echo "$A"; ?></td>
							<td><?php $val=showalarm("ifmodem");echo "$val"; ?></td>
						</tr>
					</table>
				</div>
			</div>
			<div class="mui-col-md-6">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend>Tamper Detection</legend>
					<table class="mui-table mui-table--bordered">
						<tr bgcolor="#dddddd">
							<th>Object</th>
							<th>Value</th>
							<th>Alarm</th>
						</tr>
						<tr>
							<td>Serial DTR</td>
							<td><?php 
								$A=(file_get_contents('/tmp/tbv3/objmon/tser1'));echo "$A";
							?></td>
							<td><?php $val=showalarm("tser");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>Serial DSR</td>
							<td><?php 
								$A=(file_get_contents('/tmp/tbv3/objmon/tser2'));echo "$A";
							?></td>
							<td></td>
						</tr>
						<tr>
							<td>LPT Select In</td>
							<td><?php 
								$A=(file_get_contents('/tmp/tbv3/objmon/tlpt1'));echo "$A"; 
							?></td>
							<td><?php $val=showalarm("tlpt");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>LPT Select Out</td>
							<td><?php
								$A=(file_get_contents('/tmp/tbv3/objmon/tlpt2'));echo "$A"; 
							?></td>
							<td></td>
						</tr>
						<tr>
							<td>USB Power</td>
							<td><?php
								$A=(file_get_contents('/tmp/tbv3/objmon/tusb'));echo "$A";
							?></td>
							<td><?php $val=showalarm("tusb");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>Vibration</td>
							<td><?php
								$A=(file_get_contents('/tmp/tbv3/objmon/tvibra'));echo "$A";
							?></td>
							<td><?php $val=showalarm("tvibra");echo "$val"; ?></td>
						</tr>
						<tr>
							<td>Casing</td>
							<td><?php
								$A=(file_get_contents('/tmp/tbv3/objmon/tcasing'));echo "$A";
							?></td>
							<td><?php $val=showalarm("tcasing");echo "$val"; ?></td>
						<tr>
					</table>
				</div>
			</div>
		</div>
	</div>
	</div>
</div>
<script>
/**
 * Refresh content Home dan status
 **/
var current_url = document.location;
function updateContent() {
		$("#content").load("<?echo "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";?> #Reload"); 
}
setInterval(updateContent, 15000); // 15 detik | 1000 = 1 dtk
</script>
<?php include 'footer.php'; ?>
