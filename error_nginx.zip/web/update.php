<!DOCTYPE html>
<?php
  $page = $_SERVER['PHP_SELF'];
	$sec = "6000";
	$title = "Update Status";
	
	if (isset($_POST['btrestart'])){exec('sudo /opt/tbexec/restart /opt/tbexec/tbautoupdated');}
?>
<?php include 'head-nav.php'; ?>
<div id="content-wrapper">
	<div class="mui--appbar-height"></div>
	<div class="mui-container-fluid" id="content">
	<div id="Reload">
		<div class="mui-row">
			<div class="mui-col-md-12">
				<h1>Update Status</h1>
				<div class="mui--text-center">
  
    <?php
    if (file_exists('/tmp/tbv3/.tbautoupdated')==TRUE) 
      echo "<button class='mui-btn mui-btn--raised mui--bg-color-green-A400 sys-lbl'>Service AutoUpdate is running</button>";
    else
			echo "<button class='mui-btn mui-btn--raised mui-btn--danger sys-lbl'>Service AutoUpdate is stopped</button>";
		?>
				</div>
			<form method="post">
				<button name="btrestart" class="mui-btn mui-btn--raised mui-btn--primary mui--pull-right">Restart</button>
			</form>
			</div>
		</div>
		<div class="mui-row">
			<div class="mui-col-md-4">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend class="mui--divider-bottom">List File Update</legend>
					<?php
						$A=file_get_contents('/opt/autoupdate/updatelist.txt');
						//echo nl2br($A);
						echo str_replace( "\n", '<span class="mui--pull-left"><strong>> &nbsp;</strong></span><br />', $A );
					?>
				</div>
			</div>
			<div class="mui-col-md-8">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend class="mui--divider-bottom">Stamp Update List</legend>
					<?php
						$handle = popen('ls -l /opt/autoupdate/.stamp* 2>&1', 'r');
						$read = fread($handle,2048);
						echo str_replace( "\n", '<span class="mui--pull-left"><strong>> &nbsp;</strong></span><br />', $read );
						pclose($handle);
					?>
				</div>
			</div>
		</div>
		<div class="mui-row">
			<div class="mui-col-md-12">
				<div class="mui-panel mui--bg-color-grey-50">
					<legend class="mui--divider-bottom">Update Logs</legend>
					<?php
						$update_log = popen('tail /var/log/tbv3/tbautoupdated.log 2>&1', 'r');
						$read_log = fread($update_log, 2048);
						//echo nl2br($read_log);
						echo str_replace( "\n", '<span class="mui--pull-left"><strong>> &nbsp;</strong></span><br />', $read_log );
						pclose($update_log);
					?>
				</div>
			</div>
		</div>
	</div>
	</div>
</div>
<script>
/**
 * Refresh content Home dan status
 **/
var current_url = document.location;
function updateContent() {
		$("#content").load("<?echo "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";?> #Reload"); 
}
setInterval(updateContent, 15000); // 15 detik | 1000 = 1 dtk
</script>
<?php include 'footer.php'; ?>
